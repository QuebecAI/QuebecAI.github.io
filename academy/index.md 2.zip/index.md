---
title: QUÉBEC.AI | Québec Artificial Intelligence
---
## **Québec.AI Academy**

## __ONLINE EVENT : ARTIFICIAL INTELLIGENCE 101__

### __The First World-Class Overview of AI for All__

For the newcomers to artificial intelligence, the __General Secretariat of MONTREAL.AI__ introduces, with authority and insider knowledge: "__*Artificial Intelligence 101*__: *The First World-Class Overview of AI for the General Public*".

[![ONLINE EVENT : ARTIFICIAL INTELLIGENCE 101](../images/academy1920cover_v0.jpg "ARTIFICIAL INTELLIGENCE 101")](https://artificialintelligence101.eventbrite.ca)

This AI 101 tutorial (webinar) harnesses the fundamentals of artificial intelligence for the purpose of providing participants with powerful AI tools to *learn*, *deploy* and *scale AI*. __AI opens up a world of new possibilities.__

> "**_The best way to predict the future is to invent it._**" — Alan Kay

<div id="eventbrite-widget-container-117895790483"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117895790483',
        iframeContainerId: 'eventbrite-widget-container-117895790483',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Language:__ Tutorial (webinar) given in __English__.

### A Well-Crafted Actionable 75 Minutes Tutorial

POWERFUL & USEFUL. This actionable tutorial (webinar) is designed to entrust participants with the mindset, the skills and the tools to see AI from an empowering new vantage point by : *exalting state of the art discoveries and science*, *curating the best open-source implementations* and *embodying the impetus that drives today’s artificial intelligence*.

__Program overview: *"Pioneering an Impactful Understanding of AI"*__

❖ __*Opening Address*__

Session 0 · __*Getting Started*__

- *In the Cloud*
- *On a Local Machine*

Session 1 · __*Deep Learning*__

- *Neural Networks*
- *Convolution Neural Networks (CNNs)*
- *Recurrent Neural Networks (RNNs)*
- *Unsupervised Deep Learning (Self-Supervised Learning, Generative Adversarial Nets and Variational Autoencoders)*

Session 2 · __*Autonomous Agents*__

- *Evolution Strategies*
- *Deep Reinforcement Learning*
- *Self Play: A Quantum Leap*
- *Deep Meta-Learning*

Session 3 · __*Environments*__

- *OpenAI Gym*
- *DeepMind Lab*
- *Unity ML-Agents*

❖ __*Closing Remarks*__

### Keynote Speaker

__Keynote: Vincent Boucher, Founding Chairman at MONTREAL.AI.__

In 1996, [Vincent Boucher](https://www.linkedin.com/in/montrealai/)  completed a **B. Sc. Theoretical Physics** _in 1 (one) year_, followed by a **Master's degree in Government Policy Analysis** (1998) and a **Master's degree in Aerospace Engineering (Space Technology)** (2000). From 2000 to 2002, he provided management consulting services for the **Canadian Space Agency**.

In 2003, Vincent Boucher founded [**MONTREAL.AI | Montréal Artificial Intelligence**](http://www.montreal.ai).

In 2016+, Vincent Boucher (username: *ceobillionaire*) ranked #1 worldwide on the OpenAI Gym : https://gym.openai.com/read-only.html

__A Legendary History | How It All Began —__ Learn the Source of an Exceptional Legacy :

<p align="center">[![A Legendary History | How It All Began](../images/journalmontreal.jpg "A Legendary History | How It All Began")](http://www.montreal.ai/mtl.pdf)</p>

- [Vincent Boucher | ... un cerveau de l'aérospatial!](http://www.montreal.ai/mtl.pdf) — Le journal de Montreal
- [Shooting Stars | Vincent Boucher](http://www.montreal.ai/csa.pdf) — The Canadian Space Agency Employee Newsletter
- [Vincent Boucher | Un (jeune) homme d'exception](http://www.montreal.ai/lapresse.pdf) — Nathalie Petrowski, La Presse

> "**_(AI) will rank among our greatest technological achievements, and everyone deserves to play a role in shaping it._**" — Fei-Fei Li

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Tickets:__ https://artificialintelligence101.eventbrite.ca

__Language:__ Tutorial (webinar) given in __English__.
__Date And Time:__ Sat, March 13, 2021 | 10:00 AM – 11:30 AM EST
__Location: This is an online event.__ This is a live streamed webinar with interaction with and among students. *Attendees will receive instructions on how to access at 9:45 AM (EST) on Sat, Mar 13, 2021*.

** The content of the webinar is for your personal use and should not be shared or/and distributed. __In case of force majeure, the event will be postponed to a later date.__

***

### VIP AI 101 CheatSheet for All

{% blockquote VIP AI 101 CheatSheet for All http://www.montreal.ai/ai4all.pdf http://www.montreal.ai/ai4all.pdf %}
For the purpose of entrusting all sentient beings with powerful AI tools to learn, deploy and scale AI in order to enhance their prosperity, to settle planetary-scale problems and to inspire those who, with AI, will shape the 21st Century, __Montréal.AI__ introduces the "__*VIP AI 101 CheatSheet*__ for All".
{% endblockquote %}

***

## __Curated Open-Source Codes, Implementations and Science__

### __QUÉBEC.AI__ is Preparing a **_Global Network of Education Centers_** to Pioneer an Impactful Understanding of AI and to **Foster a Vector for Safe Humanitarian Artificial General Intelligence** (AGI).

__Montréal.AI__ created the largest artificial intelligence community in Canada. **_Join us, learn and discuss_** at https://www.facebook.com/groups/MontrealAI/ !

[![Curated Open-Source Codes, Implementations and Science](../images/MontrealAI1440.jpg "Curated Open-Source Codes, Implementations and Science")](http://montreal.ai/MontrealAI101.jpg)

{% blockquote Andrew Ng https://www.quora.com/I-want-to-pursue-machine-learning-as-a-career-but-not-sure-if-I-am-qualified-How-can-I-test-myself/answer/Andrew-Ng I want to pursue machine learning as a career but not sure if I am qualified... %}
You are qualified for a career in machine learning!
{% endblockquote %}

### 0. Getting Started

__AI opens up a world of new possibilities.__ Today’s artificial intelligence is powerful, useful and accessible to all.

Tinker with Neural Networks : [Neural Network Playground](http://playground.tensorflow.org/) — TensorFlow

__In the Cloud__

Free GPU compute via [Colab](https://colab.research.google.com/notebooks/welcome.ipynb).

<p align="center">[![Colaboratory is a hosted Jupyter notebook environment that is free to use and requires no setup.](../images/colab.png "Colaboratory is a hosted Jupyter notebook environment that is free to use and requires no setup.")](https://colab.research.google.com/notebooks/welcome.ipynb)</p>

- [Colab: An easy way to learn and use TensorFlow](https://medium.com/tensorflow/colab-an-easy-way-to-learn-and-use-tensorflow-d74d1686e309) — TensorFlow
- [Six easy ways to run your Jupyter Notebook in the cloud](https://www.dataschool.io/cloud-services-for-jupyter-notebook/) — Data School
- [Practice Immediately](https://colab.research.google.com/github/GokuMohandas/practicalAI/) — Goku Mohandas

__On a Local Machine__

[Install](https://www.anaconda.com/download/) Anaconda and Launch ‘*Anaconda Navigator*’.

[![JupyterLab is Ready for Users.](../images/JupyterLab.png "JupyterLab is an interactive development environment for working with notebooks, code, and data.")](https://blog.jupyter.org/jupyterlab-is-ready-for-users-5a6f039b8906)

Update Jupyterlab and Launch the Application. Under Notebook, Click on ‘*Python 3*’.

__In the Browser__

[TensorFlow.js](https://js.tensorflow.org/): a library for developing and training ML models in JavaScript.

- [TensorFlow dev summit](https://www.youtube.com/watch?v=YB-kfeNIPCE) Official TensorFlow.js Launch
- [Introducing TensorFlow.js: Machine Learning in Javascript](https://medium.com/tensorflow/introducing-tensorflow-js-machine-learning-in-javascript-bf3eab376db) —  Josh Gordon, Sara Robinson
- [TensorFlow.js: Machine Learning for the Web and Beyond](https://arxiv.org/abs/1901.05350) — Daniel Smilkov, Nikhil Thorat, Yannick Assogba, Ann Yuan, Nick Kreeger, Ping Yu, Kangyi Zhang, Shanqing Cai, Eric Nielsen, David Soergel, Stan Bileschi, Michael Terry, Charles Nicholson, Sandeep N. Gupta, Sarah Sirajuddin, D. Sculley, Rajat Monga, Greg Corrado, Fernanda B. Viegas, Martin Wattenberg

__Datasets__

[Making it easier to discover datasets](https://www.blog.google/products/search/making-it-easier-discover-datasets/).

[![Google Dataset Search](../images/googledatasetsearch.png "Google Dataset Search")](https://toolbox.google.com/datasetsearch)

__Preliminary Readings__

> "**_When you first study a field, it seems like you have to memorize a zillion things. You don't. What you need is to identify the 3-5 core principles that govern the field. The million things you thought you had to memorize are various combinations of the core principles._**" — J. Reed

- [Deep Learning](https://www.cs.toronto.edu/~hinton/absps/NatureDeepReview.pdf) — Yann LeCun, Yoshua Bengio, Geoffrey Hinton
- [Papers With Code! | Over 950+ ML tasks, 500+ evaluation tables (including state of the art results) and 8500+ papers with code!](https://paperswithcode.com/sota) — Atlas ML
- [Learn X in Y minutes (Where X=python3)](https://learnxinyminutes.com/docs/python3/) — Louie Dinh
- [6.S191: Introduction to Deep Learning | MIT's official introductory course on deep learning methods and applications.](http://introtodeeplearning.com) — Alexander Amini and Ava Soleimany
- [Practical Deep Learning for Coders 2019](https://www.fast.ai/2019/01/24/course-v3/) — Jeremy Howard
- [Foundations Built for a General Theory of Neural Networks](https://www.quantamagazine.org/foundations-built-for-a-general-theory-of-neural-networks-20190131/) — Kevin Hartnett
- [The Matrix Calculus You Need For Deep Learning](http://parrt.cs.usfca.edu/doc/matrix-calculus/index.html) — Terence Parr, Jeremy Howard
- [Introduction to the math of backprop](https://github.com/DebPanigrahi/Machine-Learning/blob/master/back_prop.ipynb) — Deb Panigrahi
- [Introduction to Applied Linear Algebra – Vectors, Matrices, and Least Squares](https://web.stanford.edu/~boyd/vmls/) — Stephen Boyd and Lieven Vandenberghe, Cambridge University Press

<p align="center">![The Loss Landscape. Source: Visuals by Javier Ideami.](../images/LossLandscape.gif "The Loss Landscape. Source: Visuals by Javier Ideami.")</p>

- [What are the limits of deep learning?](https://www.pnas.org/content/pnas/116/4/1074.full.pdf) — M. Mitchell Waldrop
- ["A birds-eye view of optimization algorithms"](http://fa.bianp.net/teaching/2018/eecs227at/) — Fabian Pedregosa
- [Using Nucleus and TensorFlow for DNA Sequencing Error Correction](https://medium.com/tensorflow/using-nucleus-and-tensorflow-for-dna-sequencing-error-correction-47f3f7fc1a50) — Gunjan Baid, Helen Li and Pi-Chuan Chang
- [Dive into Deep Learning](http://en.diveintodeeplearning.org) — Aston Zhang, Zack C. Lipton, Mu Li, Alex J. Smola
- [How to visualize decision trees](http://explained.ai/decision-tree-viz/index.html) — Terence Parr, Prince Grover
- [Machine Learning for Visualization](https://medium.com/@enjalot/machine-learning-for-visualization-927a9dff1cab) — Ian Johnson
- [Seeing Theory: A visual introduction to probability and statistics.](https://seeing-theory.brown.edu) — Daniel Kunin et al.
- [explained.ai | Deep explanations of machine learning ](https://explained.ai) — Terence Parr
- [What is torch.nn really?](https://pytorch.org/tutorials/beginner/nn_tutorial.html) — Jeremy Howard
- [Scipy Lecture Notes](http://www.scipy-lectures.org) — Scipy
- [Deep Learning and Robotics](https://www.dropbox.com/s/dw4kmxkrv3orujd/2018_12_xx_Abbeel--AI.pdf?dl=0) — Pieter Abbeel
- [Natasha Jaques: "Recent advances in AI and machine learning" | Starsconf 2018](https://youtu.be/QI5Gvn8FDG0) — Natasha Jaques | Starsconf 2018
- [CS 188 | Introduction to Artificial Intelligence](https://inst.eecs.berkeley.edu/~cs188/fa18/) — Pieter Abbeel, Dan Klein
- [A Concise Handbook of TensorFlow](https://tf.wiki/index.html) — Xihan Li
- [The WIRED Guide to artificial intelligence](https://www.wired.com/story/guide-artificial-intelligence/) — WIRED
- [How to teach yourself hard things](https://jvns.ca/blog/2018/09/01/learning-skills-you-can-practice/) — Julia Evans
- [UFLDL (Unsupervised Feature Learning and Deep Learning) Tutorial](http://ufldl.stanford.edu/wiki/index.php/UFLDL_Tutorial) — Andrew Ng, Jiquan Ngiam, Chuan Yu Foo, Yifan Mai, Caroline Suen
- [Interview with The Youngest Kaggle Grandmaster: Mikel Bober-Irizar (anokas)](https://hackernoon.com/interview-with-the-youngest-kaggle-grandmaster-mikel-bober-irizar-anokas-17dfd2461070?fbclid=IwAR1YJ1G_PgeiYNmdgBumWo-RqAfOT6JuZsitnjEexFXJHVumj15I_Os8FIM) — Sanyam Bhutani, Hacker Noon
- [Cutting-Edge Face Recognition is Complicated. These Spreadsheets Make it Easier.](https://towardsdatascience.com/cutting-edge-face-recognition-is-complicated-these-spreadsheets-make-it-easier-e7864dbf0e1a) — Dave Smith
- [A radical new neural network design could overcome big challenges in AI](https://www.technologyreview.com/s/612561/a-radical-new-neural-network-design-could-overcome-big-challenges-in-ai/) — Karen Hao
- [Remarkable problem-solving ability of unicellular amoeboid organism and its mechanism](https://royalsocietypublishing.org/doi/10.1098/rsos.180396#.XBvH8i9JKBs) — Liping Zhu, Song-Ju Kim, Masahiko Hara, Masashi Aono
- [Competitive Programmer’s Handbook](https://cses.fi/book/book.pdf) — Antti Laaksonen
- [Machine Learning from scratch!](https://github.com/anhquan0412/basic_model_scratch) — Quan Tran
- [Rules of Machine Learning: Best Practices for ML Engineering](http://martin.zinkevich.org/rules_of_ml/rules_of_ml.pdf) — Martin Zinkevich
- [A Neural Network in 11 lines of Python](http://iamtrask.github.io/2015/07/12/basic-python-network/) — iamtrask

> "**_1. Multiply things together 2. Add them up 3. Replaces negatives with zeros 4. Return to step 1, a hundred times._**" — Jeremy Howard

- [How to build your own Neural Network from scratch in Python](https://towardsdatascience.com/how-to-build-your-own-neural-network-from-scratch-in-python-68998a08e4f6) — James Loy
- [Deep Gaussian Processes](http://inverseprobability.com/talks/notes/deep-gaussian-processes.html) — Neil D. Lawrence
- [Magic Sketchpad](https://magic-sketchpad.glitch.me) — Monica Dinculescu
- [AI Transformation Playbook](https://landing.ai/ai-transformation-playbook/) — Andrew Ng
- [Understand TensorFlow by mimicking its API from scratch](https://medium.com/@d3lm/understand-tensorflow-by-mimicking-its-api-from-scratch-faa55787170d) — Dominic Elm
- [Bias-Variance Decomposition](https://github.com/rasbt/mlxtend/blob/master/docs/sources/user_guide/evaluate/bias_variance_decomp.ipynb) — Sebastian Raschka
- SpaceSheet: Interactive Latent Space Exploration through a Spreadsheet Interface [Paper](https://nips2018creativity.github.io/doc/spacesheets.pdf) | [Demo](https://vusd.github.io/spacesheet/) | [Tool](http://bryanlohjy.gitlab.io/spacesheet/fonts.html) — Bryan Loh, Tom White
- [On intelligence: its creation and understanding](https://hai.stanford.edu/news/the_intertwined_quest_for_understanding_biological_intelligence_and_creating_artificial_intelligence/) — Surya Ganguli
- [NeurIPS 2018 Videos](https://nips.cc/Conferences/2018/Videos) — Thirty-second Conference on Neural Information Processing Systems
- [Machine Learning is Fun! Part 3: Deep Learning and Convolutional Neural Networks](https://medium.com/@ageitgey/machine-learning-is-fun-part-3-deep-learning-and-convolutional-neural-networks-f40359318721) — Adam Geitgey
- [The Neural Aesthetic](http://ml4a.github.io/classes/itp-F18/) — Gene Kogan
- [MONet: Unsupervised Scene Decomposition and Representation](https://arxiv.org/abs/1901.11390) — Christopher P. Burgess, Loic Matthey, Nicholas Watters, Rishabh Kabra, Irina Higgins, Matt Botvinick, Alexander Lerchner
- Popular Machine Learning Algorithms Explained [Project Jupyter](https://mybinder.org/v2/gh/trekhleb/homemade-machine-learning/master?filepath=notebooks) | [GitHub](https://github.com/trekhleb/homemade-machine-learning) — Oleksii Trekhleb
- [Introduction to Artificial Intelligence, ULiège, Fall 2018.](https://github.com/glouppe/info8006-introduction-to-ai) — Gilles Louppe
- [Deep Learning cheatsheets for Stanford's CS 230](https://github.com/afshinea/stanford-cs-230-deep-learning) — Afshine Amidi, Shervine Amidi 
- [TensorFlow Blog](https://medium.com/tensorflow) — TensorFlow
- [Machine Learning From Scratch](https://github.com/eriklindernoren/ML-From-Scratch) — Erik Linder-Norén
- [A Beginner's Guide to the Mathematics of Neural Networks](http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.161.3556&rep=rep1&type=pdf) — A.C.C. Coolen

![Types of Learning, by Alex Graves at NeurIPS 2018](../images/LearningTypes.png "Types of Learning, by Alex Graves at NeurIPS 2018.")

An embedding is [a mapping from discrete objects, such as words, to vectors of real numbers]( http://projector.tensorflow.org).

### __1. Deep Learning__

Deep learning allows computational models that are composed of multiple processing layers to learn [REPRESENTATIONS](https://www.cs.toronto.edu/~hinton/absps/NatureDeepReview.pdf)  of (raw) data with multiple levels of abstraction. At a high-level, neural networks are either encoders, decoders, or [a combination of both](https://github.com/lexfridman/mit-deep-learning).

> "**_DL is essentially a new style of programming--"differentiable programming"--and the field is trying to work out the reusable constructs in this style. We have some: convolution, pooling, LSTM, GAN, VAE, memory units, routing units, etc._**" — Thomas G. Dietterich

#### __1.1 Neural Networks__

> "**_Neural networks" are a sad misnomer. They're neither neural nor even networks. They're chains of differentiable, parameterized geometric functions,  trained with gradient descent (with gradients obtained via the chain rule). A small set of highschool-level ideas put together._**" — François Chollet

![Forward pass in a neural networks with two hidden layers](../images/FeedforwardNNv1.png "Forward pass in a neural networks with two hidden layers.")

- [AI Playbook](http://aiplaybook.a16z.com) — Andreessen Horowitz
- [Clear Explanations of Machine Learning](https://distill.pub) — Distill
- [Deep Learning Book](http://www.deeplearningbook.org) — Ian Goodfellow, Yoshua Bengio, Aaron Courville
- [Neural Networks and Deep Learning](http://neuralnetworksanddeeplearning.com) — Michael Nielsen
- [Deep Learning](https://www.udacity.com/course/deep-learning--ud730) — Vincent Vanhoucke | Google
- [A Complete Implementation of a Toy Neural Network](http://cs231n.github.io/neural-networks-case-study/) — Stanford CS class CS231n
- [Neural networks: training with backpropagation](https://www.jeremyjordan.me/neural-networks-training/) — Jeremy Jordan
- [Introduction to Machine Learning for Coders](http://course.fast.ai/ml) — Jeremy Howard
- [Machine Learning Yearning](https://d2wvfoqc9gyqzf.cloudfront.net/content/uploads/2018/09/Ng-MLY01-13.pdf) — Andrew Ng
- [Effective TensorFlow for Non-Experts](https://youtu.be/5DknTFbcGVM) — Google Developers
- [Neural Network as Ordinary Differential Equations](https://rkevingibson.github.io/blog/neural-networks-as-ordinary-differential-equations/) — Kevin Gibson
- [A curated collection of inspirational AI-powered JavaScript apps](https://aijs.rocks) — Elle Haproff, Asim Hussain, Osama Jandali
- [Pytorch Implementation of Neural Processes](https://chrisorm.github.io/NGP.html) — Chris Ormandy
- [A Few Unusual Autoencoders](https://colinraffel.com/talks/vector2018few.pdf) — Colin Raffel
- [Science of AI | How AI Training Scales](https://blog.openai.com/science-of-ai/) — OpenAI
- [Pytorch implementation of JointVAE, a framework for disentangling continuous and discrete factors of variation ](https://github.com/Schlumberger/joint-vae) — Schlumberger Software Technology
- [A New TensorFlow Hub Web Experience](https://medium.com/tensorflow/a-new-tensorflow-hub-web-experience-c804496e99f3) — André Susano Pinto, Clemens Mewald
- [Approximate Fisher Information Matrix to Characterise the Training of Deep Neural Networks](https://arxiv.org/abs/1810.06767) — Zhibin Liao, Tom Drummond, Ian Reid, Gustavo Carneiro
- [Deep Learning on Graphs: A Survey](https://www.arxiv-vanity.com/papers/1812.04202/) — Ziwei Zhang, Peng Cui, Wenwu Zhu
- [TF Jam — Shooting Hoops with Machine Learning](https://medium.com/tensorflow/tf-jam-shooting-hoops-with-machine-learning-7a96e1236c32) — Abe Haskins
- [Building Web App for Computer Vision Model & Deploying to Production in 10 Minutes*: A Detailed Guide](https://towardsdatascience.com/building-web-app-for-computer-vision-model-deploying-to-production-in-10-minutes-a-detailed-ec6ac52ec7e4) — Pankaj Mathur
- [Measuring the Effects of Data Parallelism on Neural Network Training](https://arxiv.org/abs/1811.03600) — Christopher J. Shallue, Jaehoon Lee, Joe Antognini, Jascha Sohl-Dickstein, Roy Frostig, George E. Dahl
- Photo Wake-Up: 3D Character Animation from a Single Photo [Paper](https://arxiv.org/abs/1812.02246) | [Project Page](https://grail.cs.washington.edu/projects/wakeup/) — Chung-Yi Weng, Brian Curless, Ira Kemelmacher-Shlizerman
- [Relational inductive biases, deep learning, and graph networks](https://arxiv.org/abs/1806.01261) — Peter W. Battaglia, Jessica B. Hamrick, Victor Bapst, Alvaro Sanchez-Gonzalez, Vinicius Zambaldi, Mateusz Malinowski, Andrea Tacchetti, David Raposo, Adam Santoro, Ryan Faulkner, Caglar Gulcehre, Francis Song, Andrew Ballard, Justin Gilmer, George Dahl, Ashish Vaswani, Kelsey Allen, Charles Nash, Victoria Langston, Chris Dyer, Nicolas Heess, Daan Wierstra, Pushmeet Kohli, Matt Botvinick, Oriol Vinyals, Yujia Li, Razvan Pascanu
- [Avito Demand Prediction Challenge : Kaggle winner explains how to combine categorical, numerical, image and text features into a single NN that gets you into top 10 without stacking](https://www.kaggle.com/c/avito-demand-prediction/discussion/59880) — Little Boat
- fast.ai | Making neural nets uncool again [Intro Machine Learning](http://course.fast.ai/ml) | [Practical Deep Learning](http://course.fast.ai) | [Cutting Edge Deep Learning](http://course.fast.ai/part2.html) | [Computational Linear Algebra](https://github.com/fastai/numerical-linear-algebra) —  Jeremy Howard, Rachel Thomas | Fast.AI

![Backward pass in a neural networks with two hidden layers](../images/Backpropagation.png "Backward pass in a neural networks with two hidden layers.")

##### __1.1.1 Universal Approximation Theorem__

The [universal approximation theorem](https://en.wikipedia.org/wiki/Universal_approximation_theorem) states that a feed-forward network with a single hidden layer containing a finite number of neurons can solve any given problem to arbitrarily close accuracy as long as you add enough parameters.

![The chain rule applied to one single unit. Image source: Markus Völk.](../images/ChainRule.png "The chain rule applied to one single unit. Image source: Markus Völk.")

[Neural Networks + Gradient Descent + GPU](http://wiki.fast.ai/index.php/Lesson_1_Notes):

- [Infinitely flexible function](http://neuralnetworksanddeeplearning.com/chap4.html): *__Neural Networks__* (multiple hidden layers: Deep Learning) ;
- [All-purpose parameter fitting](https://www.jeremyjordan.me/neural-networks-training/): *__Backpropagation__* ; and
- Fast and scalable: *__GPU__*.

When a choice must be made, just feed the (raw) data to a deep neural network (*universal function approximator*).

#### __1.2 Convolution Neural Network__

In images, local combinations of edges form motifs, motifs assemble into parts, and parts form objects.

The deep convolutional network, inspired by Hubel and Wiesel’s seminal work on early visual cortex, uses hierarchical layers of tiled convolutional filters to mimic the effects of receptive fields, thereby exploiting the [local spatial correlations](https://storage.googleapis.com/deepmind-media/dqn/DQNNaturePaper.pdf) present in images.

[![Architecture of LeNet-5, a Convolutional Neural Network. LeCun et al., 1998](../images/LeNet5.png "Architecture of LeNet-5, a Convolutional Neural Network. LeCun et al., 1998")](http://yann.lecun.com/exdb/publis/pdf/lecun-01a.pdf)

A ConvNet is made up of Layers. [Every Layer has a simple API](http://cs231n.github.io/convolutional-networks/): It transforms an input 3D volume to an output 3D volume with some differentiable function that may or may not have parameters.

> "**_I admire the elegance of your method of computation; it must be nice to ride through these fields upon the horse of true mathematics while the like of us have to make our way laboriously on foot._**" — A. Einstein

- [CNN Is All You Need](https://arxiv.org/abs/1712.09662) — Qiming Chen, Ren Wu
- [Feature Visualization](https://distill.pub/2017/feature-visualization/) — Chris Olah, Alexander Mordvintsev, Ludwig Schubert
- [Explanatory Graphs for CNNs](https://arxiv.org/abs/1812.07997) — Quanshi Zhang, Xin Wang, Ruiming Cao, Ying Nian Wu, Feng Shi, Song-Chun Zhu
- [Understanding Neural Networks Through Deep Visualization](http://yosinski.com/deepvis) — Jason Yosinski, Jeff Clune, Anh Nguyen, Thomas Fuchs, and Hod Lipson
- [MedicalTorch](https://medicaltorch.readthedocs.io/en/stable/) — Christian S. Perone
- [How to visualize convolutional features in 40 lines of code](https://towardsdatascience.com/how-to-visualize-convolutional-features-in-40-lines-of-code-70b7d87b0030) — Fabio M. Graetz
- [Deep Learning for Generic Object Detection: A Survey](https://arxiv.org/abs/1809.02165v1) — Li Liu, Wanli Ouyang, Xiaogang Wang, Paul Fieguth, Jie Chen, Xinwang Liu, Matti Pietikäinen
- [A Unified Theory of Early Visual Representations from Retina to Cortex through Anatomically Constrained Deep CNNs](https://arxiv.org/abs/1901.00945) — Jack Lindsey, Samuel A. Ocko, Surya Ganguli, Stephane Deny
- [The Building Blocks of Interpretability](https://distill.pub/2018/building-blocks/) — Chris Olah, Arvind Satyanarayan, Ian Johnson, Shan Carter, Ludwig Schubert, Katherine Ye, Alexander Mordvintsev
- [Detectron : State-of-the-art Object Detection](https://github.com/facebookresearch/Detectron) — Ross Girshick and Ilija Radosavovic and Georgia Gkioxari and Piotr Doll\'{a}r and Kaiming He
- [YOLOv3: An Incremental Improvement](https://pjreddie.com/media/files/papers/YOLOv3.pdf) | [WebSite](https://pjreddie.com/darknet/yolo/) | [YouTube](https://youtu.be/MPU2HistivI) — Joseph Redmon, Ali Farhadi
- [From Recognition to Cognition: Visual Commonsense Reasoning](https://arxiv.org/abs/1811.10830) — Rowan Zellers, Yonatan Bisk, Ali Farhadi, Yejin Choi
- [AdVis.js : Exploring Fast Gradient Sign Method](http://jlin.xyz/advis/) — Jason Lin, Dilara Soylu
- [Machine Learning for Artists](http://ml4a.github.io/ml4a/) | [Demos Page](http://ml4a.github.io/demos/) | [This is how convolution works](http://ml4a.github.io/demos/convolution/) — Machine Learning for Artists
- [Deep Painterly Harmonization](https://sgugger.github.io/deep-painterly-harmonization.html#deep-painterly-harmonization) | [Notebook](https://github.com/sgugger/Deep-Learning/blob/master/DeepPainterlyHarmonization.ipynb) — Sylvain Gugger
- [A Deep Learning based magnifying glass](https://medium.com/idealo-tech-blog/a-deep-learning-based-magnifying-glass-dae1f565c359) — Francesco Cardinale
- [How Convolutional Neural Networks Work](https://youtu.be/FmpDIaiMIeA) — Brandon Rohrer
- [TensorSpace: Neural network 3D visualization framework](https://tensorspace.org) —TensorSpace

<p align="center">![Interactive Inceptionv3 created by TensorSpace https://tensorspace.org](../images/TensorSpaceInteractiveInceptionv3.gif "Interactive Inceptionv3 created by TensorSpace https://tensorspace.org")</p>

#### __1.3 Recurrent Neural Networks__

__For sequential inputs.__ Recurrent neural networks are [networks with loops in them](http://colah.github.io/posts/2015-08-Understanding-LSTMs/), allowing information to persist. RNNs process an input sequence one element at a time, maintaining in their hidden units a ‘*state vector*’ that [implicitly contains information about the history](https://www.cs.toronto.edu/~hinton/absps/NatureDeepReview.pdf) of all the past elements of the sequence.

![RNN Layers Reuse Weights for Multiple Timesteps](../images/RNN.png "RNN Layers Reuse Weights for Multiple Timesteps")

- [Long Short-Term Memory](https://www.bioinf.jku.at/publications/older/2604.pdf) — Sepp Hochreiter, Jürgen Schmidhuber
- [Understanding LSTM Networks](http://colah.github.io/posts/2015-08-Understanding-LSTMs/) — Christopher Olah
- [Can Neural Networks Remember?](http://vishalgupta.me/deck/char_lstms/) — Vishal Gupta
- [Attention and Augmented RNN](https://distill.pub/2016/augmented-rnns/) — Olah & Carter, 2016
- [Computer, respond to this email](https://ai.googleblog.com/2015/11/computer-respond-to-this-email.html) — Post by Greg Corrado
- [How do Mixture Density RNNs Predict the Future?](https://arxiv.org/abs/1901.07859) — Kai Olav Ellefsen, Charles Patrick Martin, Jim Torresen
- [Reversible Recurrent Neural Networks](https://arxiv.org/abs/1810.10999) — Matthew MacKay, Paul Vicol, Jimmy Ba, Roger Grosse
- Recurrent Relational Networks [Blog](https://rasmusbergpalm.github.io/recurrent-relational-networks/) | [arXiv](https://arxiv.org/pdf/1711.08028.pdf) | [Code](https://github.com/rasmusbergpalm/recurrent-relational-networks) — Rasmus Berg Palm, Ulrich Paquet, Ole Winther

[![Google Smart Reply System is built on a pair of recurrent neural networks. Diagram by Chris Olah](../images/thoughtvector.png "Google Smart Reply System is built on a pair of recurrent neural networks. Diagram by Chris Olah")](https://ai.googleblog.com/2015/11/computer-respond-to-this-email.html)

- [The Unreasonable Effectiveness of Recurrent Neural Networks](http://karpathy.github.io/2015/05/21/rnn-effectiveness/) — Andrej Karpathy
- Massive Exploration of Neural Machine Translation Architectures [arXiv](https://arxiv.org/pdf/1703.03906.pdf) | [Docs](https://google.github.io/seq2seq/) | [Code](https://github.com/google/seq2seq) — Denny Britz, Anna Goldie, Minh-Thang Luong, Quoc Le
- A TensorFlow implementation of : "Hybrid computing using a neural network with dynamic external memory" [GitHub](https://github.com/deepmind/dnc) — Alex Graves, Greg Wayne, Malcolm Reynolds, Tim Harley, Ivo Danihelka, Agnieszka Grabska-Barwińska, Sergio Gómez Colmenarejo, Edward Grefenstette, Tiago Ramalho, John Agapiou, Adrià Puigdomènech Badia, Karl Moritz Hermann, Yori Zwols, Georg Ostrovski, Adam Cain, Helen King, Christopher Summerfield, Phil Blunsom, Koray Kavukcuoglu & Demis Hassabis

> "**_I feel like a significant percentage of Deep Learning breakthroughs ask the question "how can I reuse weights in multiple places?"
-- Recurrent (LSTM) layers reuse for multiple timesteps
-- Convolutional layers reuse in multiple locations. 
-- Capsules reuse across orientation._**" — Trask

#### __1.4 Capsules__

- [Stacked Capsule Autoencoders](http://akosiorek.github.io/ml/2019/06/23/stacked_capsule_autoencoders.html) — Adam Kosiorek
- [Dynamic Routing Between Capsules](https://arxiv.org/abs/1710.09829) — Sara Sabour, Nicholas Frosst, Geoffrey E Hinton
- [Capsule Networks (CapsNets) – Tutorial](https://youtu.be/pPN8d0E3900) — Aurélien Géron
- [Understanding Hinton’s Capsule Networks. Part I: Intuition.](https://medium.com/ai³-theory-practice-business/understanding-hintons-capsule-networks-part-i-intuition-b4b559d1159b) — Max Pechyonkin
- [Capsules for Object Segmentation](https://arxiv.org/abs/1804.04241) — Rodney LaLonde, Ulas Bagci
- [Brain Tumor Type Classification via Capsule Networks](https://arxiv.org/abs/1802.10200) — Parnian Afshar, Arash Mohammadi, Konstantinos N. Plataniotis
- [A Tensorflow implementation of CapsNet](https://github.com/naturomics/CapsNet-Tensorflow) — Huadong Liao

#### __1.5 Unsupervised Learning__

__True intelligence will require independent learning strategies.__ Unsupervised learning is a paradigm for creating AI that learns without a particular task in mind: [learning for the sake of learning](https://deepmind.com/blog/unsupervised-learning/). It captures some [characteristics of the joint distribution of the observed random variables](https://arxiv.org/abs/1811.06128) (*learn the underlying structure*).

__Self-supervised learning__ is derived form unsupervised learning where the data provides the supervision.

##### __1.5.1 Generative Adversarial Network__

Simultaneously train two models: a generative model G that captures the data distribution, and a discriminative model D that estimates the probability that a sample came from the training data rather than G. The training procedure for G is to maximize the probability of D making a mistake.

$$\min_{\theta_g} \max_{\theta_d} [{\rm IE_{x\sim p_{data}(x)}} [log D_{\theta_d}(x)] + {\rm IE_{z\sim p_z(z)}} [log(1 - D_{\theta_d}(G_{\theta_g}(z)))]]$$

> "**_What I cannot create, I do not understand._**" — Richard Feynman

This framework corresponds to a minimax two-player game. [Generative Adversarial Nets](https://arxiv.org/pdf/1406.2661.pdf) — Goodfellow et al.

- [Generative Models](https://blog.openai.com/generative-models/) — OpenAI
- [GAN Lab: Play with Generative Adversarial Networks (GANs) in your browser!](https://poloclub.github.io/ganlab/) — Minsuk Kahng, Nikhil Thorat, Polo Chau, Fernanda Viégas, Martin Wattenberg
- [Generative Adversarial Networks (GANs) in 50 lines of code (PyTorch)](https://medium.com/@devnag/generative-adversarial-networks-gans-in-50-lines-of-code-pytorch-e81b79659e3f) — Dev Nag
- [TensorFlow-GAN (TFGAN)](https://github.com/tensorflow/tensorflow/tree/master/tensorflow/contrib/gan) — TensorFlow
- [Few-Shot Adversarial Learning of Realistic Neural Talking Head Models](https://arxiv.org/abs/1905.08233)
- [Wasserstein GAN](http://www.depthfirstlearning.com/2019/WassersteinGAN)
- [GANSynth: Generate high-fidelity audio with GANs!](http://goo.gl/magenta/gansynth-demo)
- [SC-FEGAN: Face Editing Generative Adversarial Network](https://github.com/JoYoungjoo/SC-FEGAN)
- [CariGANs: Unpaired Photo-to-Caricature Translation](https://cari-gan.github.io)
- [GANpaint Paint with GAN units](http://gandissect.res.ibm.com/ganpaint.html)
- [PyTorch pretrained BigGAN](https://github.com/huggingface/pytorch-pretrained-BigGAN)
- [Neural scene representation and rendering](https://deepmind.com/blog/neural-scene-representation-and-rendering/) — S. M. Ali Eslami, Danilo J. Rezende, Frederic Besse, Fabio Viola, Ari S. Morcos, Marta Garnelo, Avraham Ruderman, Andrei A. Rusu, Ivo Danihelka, Karol Gregor, David P. Reichert, Lars Buesing, Theophane Weber, Oriol Vinyals, Dan Rosenbaum, Neil Rabinowitz, Helen King, Chloe Hillier, Matt Botvinick, Daan Wierstra, Koray Kavukcuoglu, Demis Hassabis

<p align="center">![GAN: Neural Networks Architecture Pioneered by Ian Goodfellow at University of Montreal (2014)](../images/GANs.jpeg "GAN: Neural Networks Architecture Pioneered by Ian Goodfellow at University of Montreal (2014)")</p>

- Recycle-GAN: Unsupervised Video Retargeting [Paper](http://www.cs.cmu.edu/~aayushb/Recycle-GAN/recycle_gan.pdf) | [Blog](http://www.cs.cmu.edu/~aayushb/Recycle-GAN/) — Aayush Bansal, Shugao Ma, Deva Ramanan, Yaser Sheikh
- [On Self Modulation for Generative Adversarial Networks](https://arxiv.org/abs/1810.01365) — Ting Chen, Mario Lucic, Neil Houlsby, Sylvain Gelly
- Bayesian GAN [arXiv](https://arxiv.org/abs/1705.09558) | [GitHub](https://github.com/andrewgordonwilson/bayesgan/) — Yunus Saatchi, Andrew Gordon Wilson
- [Adversarial Transfer Learning](https://arxiv.org/abs/1812.02849) — Garrett Wilson, Diane J. Cook
- [Generating Memoji from Photos](https://patniemeyer.github.io/2018/10/29/generating-memoji-from-photos.html) — Pat Niemeyer
- [GANPaint](http://gandissect.res.ibm.com/ganpaint.html?project=churchoutdoor&layer=layer4) — MIT-IBM Watson AI Lab
- [The GAN Zoo](https://github.com/hindupuravinash/the-gan-zoo) — Avinash Hindupur
- A collection of GANs [TensorFlow](https://github.com/hwalsuklee/tensorflow-generative-model-collections) | [PyTorch](https://github.com/znxlwm/pytorch-generative-model-collections)

StyleGAN: A Style-Based Generator Architecture for Generative Adversarial Networks [Paper](http://stylegan.xyz/paper) | [Code](https://github.com/NVlabs/stylegan)
- [StyleGAN for art](https://colab.research.google.com/github/ak9250/stylegan-art)
- [This Person Does Not Exist](https://thispersondoesnotexist.com)
- [Which Person Is Real?](http://www.whichfaceisreal.com)
- [This Resume Does Not Exist](https://thisresumedoesnotexist.com)
- [This Waifu Does Not Exist](https://www.thiswaifudoesnotexist.net)
- [Encoder for Official TensorFlow Implementation](https://github.com/Puzer/stylegan-encoder)
- [How to recognize fake AI-generated images](https://medium.com/@kcimc/how-to-recognize-fake-ai-generated-images-4d1f6f9a2842) — Kyle McDonald

Demo of BigGAN in an [official Colaboratory notebook (*backed by a GPU*)](https://colab.research.google.com/github/tensorflow/hub/blob/master/examples/colab/biggan_generation_with_tf_hub.ipynb)

##### __1.5.2 Variational Auto-Encoders (VAEs)__

Variational Auto-Encoders (VAEs) are powerful models for learning low-dimensional representations.

![Variational Autoencoders (VAEs): Powerful Generative Models.](../images/VAEs.png "Variational Autoencoders (VAEs): Powerful Generative Models.")

- [*Debiasing Facial Detection Systems* - Colab](https://colab.research.google.com/github/aamini/introtodeeplearning_labs/blob/master/lab2/Part2_debiasing_solution.ipynb)
- [__SpaceSheet__: Interactive Latent Space Exploration with a Spreadsheet](https://vusd.github.io/spacesheet/)
- [__MusicVAE__: Learning latent spaces for musical scores](https://magenta.tensorflow.org/music-vae)
- [Slides: A Few Unusual Autoencoders](https://colinraffel.com/talks/vector2018few.pdf)
- [Generative models in __Tensorflow 2__](https://github.com/timsainb/tensorflow2-generative-models/)
- [Disentangled VAE's (DeepMind 2016)](https://arxiv.org/abs/1606.05579)

> "**_I think transfer learning is the key to general intelligence. And I think the key to doing transfer learning will be the acquisition of conceptual knowledge that is abstracted away from perceptual details of where you learned it from._**" — Demis Hassabis

### __2. Autonomous Agents__

Reinforcement learning (RL) studies how an agent can learn how to achieve goals in a complex, uncertain environment.

[![Artificial Intelligence 101: The First World-Class Overview of AI for the General Public | Autonomous Agents](../images/AutonomousAgents.jpeg "Artificial Intelligence 101: The First World-Class Overview of AI for the General Public | Autonomous Agents")](https://montrealai101.eventbrite.ca)

An __autonomous agent__ is any device that perceives its environment and takes actions that maximize its chance of success at some goal. At the bleeding edge of AI, autonomous agents can learn from experience, simulate worlds and orchestrate meta-solutions. Here’s an [informal definition](https://arxiv.org/abs/0712.3329) of the *universal intelligence* of agent \`\pi\`

$$\Upsilon(\pi) := \sum\limits_{\mu \in E} 2^{-K(\mu)} V^{\pi}_{\mu}$$

> "**_Intelligence measures an agent’s ability to achieve goals in a wide range of environments._**" — Shane Legg

#### __2.1 Evolution Strategies__

> "**_Evolution is a slow learning algorithm that with the sufficient amount of compute produces a human brain._**" — Wojciech Zaremba

Evolution and neural networks proved a potent combination in [nature](https://www.nature.com/articles/s42256-018-0006-z.pdf). [Natural evolutionary strategy directly evolves the weights of a DNN](https://blog.openai.com/evolution-strategies/) and performs competitively with the best deep reinforcement learning algorithms. Neuroevolution enables capabilities that are typically unavailable to gradient-based approaches.

- [A Visual Guide to Evolution Strategies](http://blog.otoro.net/2017/10/29/visual-evolution-strategies/) — David Ha
- [Evolution Strategies as a Scalable Alternative to Reinforcement Learning](https://blog.openai.com/evolution-strategies/) — OpenAI

[![Exploiting Potential Energy to Locomote. Source: The Surprising Creativity of Digital Evolution: A Collection of Anecdotes from the Evolutionary Computation and Artificial Life Research Communities.](../images/ExploitingPotentialEnergyLocomote.png "Exploiting Potential Energy to Locomote. Source: The Surprising Creativity of Digital Evolution: A Collection of Anecdotes from the Evolutionary Computation and Artificial Life Research Communities.")](https://arxiv.org/abs/1803.03453)

- [The Surprising Creativity of Digital Evolution: A Collection of Anecdotes from the Evolutionary Computation and Artificial Life Research Communities](https://arxiv.org/abs/1803.03453) — Joel Lehman, Jeff Clune, Dusan Misevic, Christoph Adami, Lee Altenberg, Julie Beaulieu, Peter J. Bentley, Samuel Bernard, Guillaume Beslon, David M. Bryson, Patryk Chrabaszcz, Nick Cheney, Antoine Cully, Stephane Doncieux, Fred C. Dyer, Kai Olav Ellefsen, Robert Feldt, Stephan Fischer, Stephanie Forrest, Antoine Frénoy, Christian Gagné, Leni Le Goff, Laura M. Grabowski, Babak Hodjat, Frank Hutter, Laurent Keller, Carole Knibbe, Peter Krcah, Richard E. Lenski, Hod Lipson, Robert MacCurdy, Carlos Maestre, Risto Miikkulainen, Sara Mitri, David E. Moriarty, Jean-Baptiste Mouret, Anh Nguyen, Charles Ofria, Marc Parizeau, David Parsons, Robert T. Pennock, William F. Punch, Thomas S. Ray, Marc Schoenauer, Eric Shulte, Karl Sims, Kenneth O. Stanley, François Taddei, Danesh Tarapore, et al. (4 additional authors not shown)
- [Evolving Neural Networks](http://nn.cs.utexas.edu/downloads/slides/miikkulainen.ijcnn13.pdf) — Risto Miikkulainen
- [Recombination of Artificial Neural Networks](https://arxiv.org/abs/1901.03900) — Aaron Vose, Jacob Balma, Alex Heye, Alessandro Rigazzi, Charles Siegel, Diana Moise, Benjamin Robbins, Rangan Sukumar
- [Nevergrad: An open source tool for derivative-free optimization](https://code.fb.com/ai-research/nevergrad/) — J. Rapin and O. Teytaud
- [Evolved Policy Gradients](https://arxiv.org/abs/1802.04821) — Rein Houthooft, Richard Y. Chen, Phillip Isola, Bradly C. Stadie, Filip Wolski, Jonathan Ho, Pieter Abbeel
- [Using Evolutionary AutoML to Discover Neural Network Architectures](https://ai.googleblog.com/2018/03/using-evolutionary-automl-to-discover.html) — Google AI

<p align="center">![Flexible Muscle-Based Locomotion for Bipedal Creatures. Source: ACM Transactions on Graphics, Vol. 32, Nr. 6 (Proc. of SIGGRAPH Asia 2013).](../images/BipedalCreatures.mp4 "Flexible Muscle-Based Locomotion for Bipedal Creatures. Source: ACM Transactions on Graphics, Vol. 32, Nr. 6 (Proc. of SIGGRAPH Asia 2013).")</p>

Neural architecture search has advanced to the point where it can [outperform human-designed](https://arxiv.org/abs/1901.11117) models.

> "**_... evolution — whether biological or computational — is inherently creative, and should routinely be expected to surprise, delight, and even outwit us._**" — The Surprising Creativity of Digital Evolution, [Lehman et al.](https://arxiv.org/abs/1803.03453)

#### __2.2 Deep Reinforcement Learning__

In reinforcement learning, an agent interacts with an environment through a Markov decision process.

![An Agent Interacts with an Environment](../images/AgentEnvironment.png "An Agent Interacts with an Environment.")

The goal in reinforcement learning is to train the agent to maximize the sum of future rewards, called the return.

- [Reinforcement Learning: An Introduction](https://drive.google.com/file/d/1opPSz5AZ_kVa1uWOdOiveNiBFiEOHjkG/view) — Andrew Barto and Richard S. Sutton
- [Spinning Up as a Deep RL Researcher](https://spinningup.openai.com/en/latest/spinningup/spinningup.html) — Joshua Achiam
- [Intuitive RL: Intro to Advantage-Actor-Critic (A2C)](https://medium.com/@rudygilman/intuitive-rl-intro-to-advantage-actor-critic-a2c-4ff545978752) — Rudy Gilman
- [Simple Beginner’s guide to Reinforcement Learning & its implementation](https://www.analyticsvidhya.com/blog/2017/01/introduction-to-reinforcement-learning-implementation/) — Faizan Shaikh
- [Spinning Up in Deep RL](https://blog.openai.com/spinning-up-in-deep-rl/) — Joshua Achiam
- [AlphaStar: Mastering the Real-Time Strategy Game StarCraft II](https://deepmind.com/blog/alphastar-mastering-real-time-strategy-game-starcraft-ii/) — Oriol Vinyals, Igor Babuschkin, Junyoung Chung, Michael Mathieu, Max Jaderberg, Wojtek Czarnecki, Andrew Dudzik, Aja Huang, Petko Georgiev, Richard Powell, Timo Ewalds, Dan Horgan, Manuel Kroiss, Ivo Danihelka, John Agapiou, Junhyuk Oh, Valentin Dalibard, David Choi, Laurent Sifre, Yury Sulsky, Sasha Vezhnevets, James Molloy, Trevor Cai, David Budden, Tom Paine, Caglar Gulcehre, Ziyu Wang, Tobias Pfaff, Toby Pohlen, Dani Yogatama, Julia Cohen, Katrina McKinney, Oliver Smith, Tom Schaul, Timothy Lillicrap, Chris Apps, Koray Kavukcuoglu, Demis Hassabis, David Silver
- [Creating a Zoo of Atari-Playing Agents to Catalyze the Understanding of Deep Reinforcement Learning](https://eng.uber.com/atari-zoo-deep-reinforcement-learning/) — Felipe Petroski Such, Vashisht Madhavan, Rosanne Liu, Rui Wang, Yulun Li, Jeff Clune, Joel Lehman
- [An Introduction to Deep Reinforcement Learning](https://arxiv.org/abs/1811.12560) — Vincent Francois-Lavet, Peter Henderson, Riashat Islam, Marc G. Bellemare, Joelle Pineau
- [Welcome to Spinning Up in Deep RL!](https://spinningup.openai.com/en/latest/) — OpenAI
- [A (Long) Peek into Reinforcement Learning](https://lilianweng.github.io/lil-log/2018/02/19/a-long-peek-into-reinforcement-learning.html#sarsa-on-policy-td-control) — Lilian Weng
- [A Theoretical Analysis of Deep Q-Learning](https://arxiv.org/abs/1901.00137) — Zhuora Yang, Yuchen Xie, Zhaoran Wang
- [Monte Carlo Tree Search – beginners guide](https://buff.ly/2Gpr0Gm) — Kamil Czarnogórski
- [Quantifying Generalization in Reinforcement Learning](https://blog.openai.com/quantifying-generalization-in-reinforcement-learning/) — OpenAI
- [Relational Deep Reinforcement Learning](https://arxiv.org/abs/1806.01830) — Vinicius Zambaldi, David Raposo, Adam Santoro, Victor Bapst, Yujia Li, Igor Babuschkin, Karl Tuyls, David Reichert, Timothy Lillicrap, Edward Lockhart, Murray Shanahan, Victoria Langston, Razvan Pascanu, Matthew Botvinick, Oriol Vinyals, Peter Battaglia
- [Getting Started With MarathonEnvs v0.5.0a](https://medium.com/@Joebooth/gettingstartedwithmarathonenvs-v0-5-0a-c1054a0b540c) — Joe Booth
- [AlphaZero: Shedding new light on the grand games of chess, shogi and Go](https://deepmind.com/blog/alphazero-shedding-new-light-grand-games-chess-shogi-and-go/) — David Silver, Thomas Hubert, Julian Schrittwieser, Ioannis Antonoglou, Matthew Lai, Arthur Guez, Marc Lanctot, Laurent Sifre, Dharshan Kumaran, Thore Graepel, Timothy Lillicrap, Karen Simonyan, Demis Hassabis
- [DQN Adventure: from Zero to State of the Art](https://github.com/higgsfield/RL-Adventure) — higgsfield
- [SURREAL: Open-Source Reinforcement Learning Framework and Robot Manipulation Benchmark](https://surreal.stanford.edu) — Linxi Fan, Yuke Zhu, Jiren Zhu, Zihua Liu, Anchit Gupta, Joan Creus-Costa, Silvio Savarese, Li Fei-Fei
- [Learning to Act by Predicting the Future](https://arxiv.org/abs/1611.01779) — Alexey Dosovitskiy, Vladlen Koltun
- [AlphaFold: Using AI for scientific discovery](https://deepmind.com/blog/alphafold/) — Andrew Senior, John Jumper, Demis Hassabis
- [POET: Endlessly Generating Increasingly Complex and Diverse Learning Environments and their Solutions through the Paired Open-Ended Trailblazer](https://eng.uber.com/poet-open-ended-deep-learning/) — Rui Wang, Joel Lehman, Jeff Clune, Kenneth O. Stanley
- [Reinforcement Learning with Prediction-Based Rewards](https://blog.openai.com/reinforcement-learning-with-prediction-based-rewards/) — Yura Burda, Harri Edwards, OpenAI
- Playing hard exploration games by watching YouTube [Paper](https://papers.nips.cc/paper/7557-playing-hard-exploration-games-by-watching-youtube.pdf) | [YouTube](https://www.youtube.com/watch?v=s8ZSVfYmtpc&feature=youtu.be) — Yusuf Aytar, Tobias Pfaff, David Budden, Tom Le Paine, Ziyu Wang, Nando de Freitas
- Exploration by Random Network Distillation [Paper](https://arxiv.org/abs/1810.12894) | [Code](https://github.com/openai/random-network-distillation) — Yuri Burda, Harrison Edwards, Amos Storkey, Oleg Klimov
- Large-Scale Study of Curiosity-Driven Learning [Paper](https://arxiv.org/abs/1808.04355) | [Code](https://github.com/openai/large-scale-curiosity) — Yuri Burda, Harri Edwards, Deepak Pathak, Amos Storkey, Trevor Darrell, Alexei A. Efros
- [OpenAI Baselines : A2C | ACER | ACKTR | DDPG | DQN | GAIL | HER | PPO2 | TRPO](https://github.com/openai/baselines) — OpenAI
- Stable Baselines is a set of improved implementations of Reinforcement Learning (RL) algorithms based on OpenAI Baselines [Docs](https://stable-baselines.readthedocs.io/en/master/) | [Blog](https://towardsdatascience.com/stable-baselines-a-fork-of-openai-baselines-reinforcement-learning-made-easy-df87c4b2fc82) | [Code](https://github.com/hill-a/stable-baselines) — Antonin Raffin
- TRPO-GAE [Blog](https://blog.openai.com/openai-baselines-ppo/) | [arXiv](https://arxiv.org/pdf/1502.05477.pdf) | [arXiv](https://arxiv.org/pdf/1506.02438.pdf) — OpenAI
- [Improvised Robotic Design with Found Objects](https://nips2018creativity.github.io/doc/improvised_robotic_design.pdf) — Azumi Maekawa, Ayaka Kume, Hironori Yoshida, Jun Hatori, Jason Naradowsky, Shunta Saito

![Asynchronous Advantage Actor-Critic (A3C). Source: Petar Velickovic](../images/AsynchronousAdvantageActorCriticA3C.png "Asynchronous Advantage Actor-Critic (A3C). Source: Petar Velickovic")

- A3C [arXiv](https://arxiv.org/pdf/1602.01783.pdf) | [Medium](https://medium.com/emergent-future/simple-reinforcement-learning-with-tensorflow-part-8-asynchronous-actor-critic-agents-a3c-c88f72a5e9f2) | [Code](https://github.com/openai/universe-starter-agent) — OpenAI
- [Deep Reinforcement Learning](http://rail.eecs.berkeley.edu/deeprlcourse/) — Sergey Levine
- [Vel: PyTorch meets baselines](https://blog.millionintegrals.com/vel-pytorch-meets-baselines/) — Jerry
- [Continual Match Based Training in Pommerman: Technical Report](https://arxiv.org/abs/1812.07297) — Peng Peng, Liang Pang, Yufeng Yuan, Chao Gao
- [Actor-Critic Policy Optimization in Partially Observable Multiagent Environments](https://arxiv.org/abs/1810.09026) — Sriram Srinivasan, Marc Lanctot, Vinicius Zambaldi, Julien Perolat, Karl Tuyls, Remi Munos, Michael Bowling
- [TensorFlow Reinforcement Learning](https://github.com/deepmind/trfl/) — DeepMind
- [TensorFlow Agents](https://github.com/tensorflow/agents) — TensorFlow
- TensorFlow.js Implementation of DeepMind's AlphaZero Algorithm for Chess [Live Demo](https://frpays.github.io/lc0-js/engine.html) | [Code](https://github.com/frpays/lc0-js/) — François Pays
- [DiCE: The Infinitely Differentiable Monte Carlo Estimator](http://whirl.cs.ox.ac.uk/blog/dice-the-infinitely-differentiable-monte-carlo-estimator/) — Vitaly Kurin, Jakob Foerster, Shimon Whiteson
- [TorchCraftAI: A bot platform for machine learning research on StarCraft®: Brood War®](https://torchcraft.github.io/TorchCraftAI/) — Facebook
- [Curiosity and Procrastination in Reinforcement Learning](https://ai.googleblog.com/2018/10/curiosity-and-procrastination-in.html) — Nikolay Savinov, Timothy Lillicrap
- [Hierarchical Actor-Critic](https://arxiv.org/abs/1712.00948) — Andrew Levy, Robert Platt, Kate Saenko
- [Montezuma’s Revenge Solved by Go-Explore, a New Algorithm for Hard-Exploration Problems](http://eng.uber.com/go-explore/) — Adrien Ecoffet, Joost Huizinga, Joel Lehman, Kenneth O. Stanley, Jeff Clune
- [Computational Theories of Curiosity-Driven Learning](https://arxiv.org/abs/1802.10546) — Pierre-Yves Oudeyer
- [Depth-Limited Solving for Imperfect-Information Games](https://arxiv.org/abs/1805.08195) — Noam Brown, Tuomas Sandholm, Brandon Amos
- [Optimizing Expectations: From Deep Reinforcement Learning to Stochastic Computation Graphs](http://joschu.net/docs/thesis.pdf) — John Schulman
- [Neural Episodic Control](https://arxiv.org/abs/1703.01988) — Alexander Pritzel, Benigno Uria, Sriram Srinivasan, Adrià Puigdomènech, Oriol Vinyals, Demis Hassabis, Daan Wierstra, Charles Blundell
- [RLlib: Abstractions for Distributed Reinforcement Learning](http://arxiv.org/abs/1712.09381) — Eric Liang, Richard Liaw, Philipp Moritz, Robert Nishihara, Roy Fox, Ken Goldberg, Joseph E. Gonzalez, Michael I. Jordan, Ion Stoica
- [TreeQN and ATreeC: Differentiable Tree-Structured Models for Deep Reinforcement Learning](https://arxiv.org/abs/1710.11417) — Gregory Farquhar, Tim Rocktäschel, Maximilian Igl, Shimon Whiteson
- [Q-map: a Convolutional Approach for Goal-Oriented Reinforcement Learning](https://arxiv.org/abs/1810.02927) — Fabio Pardo, Vitaly Levdik, Petar Kormushev
- [Learning to Search with MCTSnets](https://arxiv.org/abs/1802.04697) — Arthur Guez, Théophane Weber, Ioannis Antonoglou, Karen Simonyan, Oriol Vinyals, Daan Wierstra, Rémi Munos, David Silver
- [Convergence of Value Aggregation for Imitation Learning](https://arxiv.org/abs/1801.07292) — Ching-An Cheng, Byron Boots
- [Dopamine : DQN | C51 | Rainbow | Implicit Quantile Network](https://github.com/google/dopamine) — Marc G. Bellemare, Pablo Samuel Castro, Carles Gelada, Saurabh Kumar, Subhodeep Moitra
- [S-RL Toolbox: Reinforcement Learning (RL) and State Representation Learning (SRL) for Robotics](https://github.com/araffin/robotics-rl-srl) — Antonin RAFFIN
- [Advanced Deep Learning and Reinforcement Learning](https://www.youtube.com/playlist?list=PLqYmG7hTraZDNJre23vqCGIVpfZ_K2RZs) — DeepMind Researchers
- Reinforcement Learning for Improving Agent Design [arXiv](https://arxiv.org/abs/1810.03779) | [Blog](https://designrl.github.io) — David Ha
- Deep Reinforcement Learning from Human Preferences [arXiv](https://arxiv.org/pdf/1706.03741.pdf) | [Blog](https://blog.openai.com/gathering_human_feedback/) | [Code](https://github.com/nottombrown/rl-teacher) — OpenAI
- [Introduction to Learning to Trade with Reinforcement Learning](http://www.wildml.com/2018/02/introduction-to-learning-to-trade-with-reinforcement-learning/) — Denny Britz
- [Closing the Sim-to-Real Loop: Adapting Simulation Randomization with Real World Experience](https://arxiv.org/abs/1810.05687) — Yevgen Chebotar, Ankur Handa, Viktor Makoviychuk, Miles Macklin, Jan Issac, Nathan Ratliff, Dieter Fox
- [Robustness via Retrying: Closed-Loop Robotic Manipulation with Self-Supervised Learning](https://sites.google.com/view/robustness-via-retrying) — Frederik Ebert, Sudeep Dasari, Alex X. Lee, Sergey Levine, Chelsea Finn
- [CURIOUS: Intrinsically Motivated Multi-Task, Multi-Goal Reinforcement Learning](https://arxiv.org/abs/1810.06284) — Cédric Colas, Olivier Sigaud, Pierre-Yves Oudeyer
- [Bayesian Optimization in AlphaGo](https://arxiv.org/abs/1812.06855) — Yutian Chen, Aja Huang, Ziyu Wang, Ioannis Antonoglou, Julian Schrittwieser, David Silver, Nando de Freitas
- [One-Shot High-Fidelity Imitation: Training Large-Scale Deep Nets with RL](https://arxiv.org/abs/1810.05017) — Tom Le Paine, Sergio Gómez Colmenarejo, Ziyu Wang, Scott Reed, Yusuf Aytar, Tobias Pfaff, Matt W. Hoffman, Gabriel Barth-Maron, Serkan Cabi, David Budden, Nando de Freitas
- [Optimizing Agent Behavior over Long Time Scales by Transporting Value](https://arxiv.org/abs/1810.06721) — Chia-Chun Hung, Timothy Lillicrap, Josh Abramson, Yan Wu, Mehdi Mirza, Federico Carnevale, Arun Ahuja, Greg Wayne
- [Large-Scale Study of Curiosity-Driven Learning](https://pathak22.github.io/large-scale-curiosity/) — Yuri Burda, Harri Edwards, Deepak Pathak, Amos Storkey, Trevor Darrell, Alexei A. Efros
- [Learning to Dress: Synthesizing Human Dressing Motion via Deep Reinforcement Learning](https://www.cc.gatech.edu/~aclegg3/projects/LearningToDress.html) — Alexander Clegg, Wenhao Yu, Jie Tan, C. Karen Liu, Greg Turk, SIGGRAPH Asia 2018
- [Automatic Poetry Generation with Mutual Reinforcement Learning](http://aclweb.org/anthology/D18-1353) — Xiaoyuan Yi, Maosong Sun, Ruoyu Li, Wenhao Li
- [Learning to Communicate with Deep Multi-Agent Reinforcement Learning in PyTorch](https://github.com/minqi/learning-to-communicate-pytorch) — Minqi Jiang
- [Learning to Navigate the Web](https://openreview.net/forum?id=BJemQ209FQ) — Anonymous
- [Understanding & Generalizing AlphaGo Zero](https://openreview.net/forum?id=rkxtl3C5YX) — Anonymous
- [Deep RL Bootcamp](https://sites.google.com/view/deep-rl-bootcamp/lectures) — Pieter Abbeel, Yan (Rocky) Duan, Xi (Peter) Chen, Andrej Karpathy

[![Open-source RL](../images/OpenSourceRL.png "Open-source RL")](https://docs.google.com/spreadsheets/d/1EeFPd-XIQ3mq_9snTlAZSsFY7Hbnmd7P5bbT8LPuMn0/edit#gid=0)

##### __2.2.1 Model-Based RL__

In Model-Based RL, the agent generates predictions about the next state and reward before choosing each action.

- [World Models](https://worldmodels.github.io) — David Ha, Jürgen Schmidhuber
- [Imagination-Augmented Agents for Deep Reinforcement Learning](https://arxiv.org/abs/1707.06203) — Théophane Weber, Sébastien Racanière, David P. Reichert, Lars Buesing, Arthur Guez, Danilo Jimenez Rezende, Adria Puigdomènech Badia, Oriol Vinyals, Nicolas Heess, Yujia Li, Razvan Pascanu, Peter Battaglia, Demis Hassabis, David Silver, Daan Wierstra
- [Learning Latent Dynamics for Planning from Pixels](https://planetrl.github.io/) — Hafner et al.
- [Mastering Chess and Shogi by Self-Play with a General Reinforcement Learning Algorithm (AlphaZero)](https://arxiv.org/abs/1712.01815) — Silver et al.

> "**_No superintelligent AI is going to bother with a task that is harder than hacking its reward function._**" — The Lebowski theorem

#### __2.3 Self Play__

__Self-play__ mirrors similar insights from coevolution.

__*AlphaGo Zero*__ showed that algorithms matter much more than big data and massive amounts of computation:

[![AlphaGo Zero : Algorithms matter much more than big data and massive amounts of computation](../images/AlphaGoZero.mp4 "AlphaGo Zero : Algorithms matter much more than big data and massive amounts of computation")](https://deepmind.com/blog/alphago-zero-learning-scratch/)

> "**_Self-Play is Automated Knowledge Creation._**" — Carlos E. Perez

Transfer learning is the key to go from self-play to the real world.

- [Explaining AlphaGo: Interpreting Contextual Effects in Neural Networks](https://arxiv.org/abs/1901.02184) — Zenan Ling, Haotian Ma, Yu Yang, Robert C. Qiu, Song-Chun Zhu, Quanshi Zhang
- [Deep Learning: AlphaGo Zero Explained In One Picture](https://www.datasciencecentral.com/profiles/blogs/deep-learning-alphago-zero-explained-in-one-picture) — L.V.
- [How to build your own AlphaZero AI using Python and Keras](https://medium.com/applied-data-science/how-to-build-your-own-alphazero-ai-using-python-and-keras-7f664945c188) — David Foster
- [An open-source implementation of the AlphaGoZero algorithm](https://github.com/tensorflow/minigo) — TensorFlow
- [ELF OpenGo: An Open Reimplementation of AlphaZero](https://arxiv.org/abs/1902.04522) — Tian et al.
- TensorFlow.js Implementation of DeepMind’s AlphaZero Algorithm for Chess. [Live Demo](https://frpays.github.io/lc0-js/engine.html) | [Code](https://github.com/frpays/lc0-js/) — François Pays

#### __2.4 Multi-Agent Populations__

- [Machine Theory of Mind](https://arxiv.org/abs/1802.07740) — Rabinowitz et al.
- [A Unified Game-Theoretic Approach to Multiagent Reinforcement Learning](https://arxiv.org/pdf/1711.00832.pdf) — Lanctot et al.
- [Continuous Adaptation via Meta-Learning in Nonstationary and Competitive Environments](https://arxiv.org/pdf/1710.03641.pdf) — Al-Shedivat et al.
- [Intrinsic Social Motivation via Causal Influence in Multi-Agent RL](https://arxiv.org/abs/1810.08647) — Natasha Jaques, Angeliki Lazaridou, Edward Hughes, Caglar Gulcehre, Pedro A. Ortega, DJ Strouse, Joel Z. Leibo, Nando de Freitas
- [Autonomous Agents Modelling Other Agents: A Comprehensive Survey and Open Problems](http://www.cs.utexas.edu/~pstone/Papers/bib2html-links/AIJ18-Albrecht.pdf) — Stefano V. Albrecht, Peter Stone
- Learning with Opponent-Learning Awareness [Paper](https://arxiv.org/pdf/1709.04326.pdf) | [Blog](https://blog.openai.com/learning-to-model-other-minds/) — OpenAI
- GPU-Accelerated Robotic Simulation for Distributed Reinforcement Learning [Paper](https://arxiv.org/abs/1810.05762) | [Blog](https://news.developer.nvidia.com/nvidia-researchers-develop-reinforcement-learning-algorithm-to-train-thousands-of-robots-simultaneously/) — Jacky Liang, Viktor Makoviychuk, Ankur Handa, Nuttapong Chentanez, Miles Macklin, Dieter Fox, NVIDIA
- Multi-Agent Actor-Critic for Mixed Cooperative-Competitive Environments [Paper](https://arxiv.org/pdf/1706.02275.pdf) | [Blog](https://blog.openai.com/learning-to-cooperate-compete-and-communicate/) | [Code](https://github.com/openai/maddpg/) — OpenAI

#### __2.5 Deep Meta-Learning__

[__Learning to Learn__](https://arxiv.org/abs/1606.04474). The goal of meta-learning is to train a model on a variety of learning tasks, such that [it can solve new learning tasks using only a small number of training samples](https://arxiv.org/abs/1703.03400). A meta-learning algorithm takes in a distribution of tasks, where each task is a learning problem, and it produces a quick learner — [a learner that can generalize from a small number of examples](https://blog.openai.com/reptile/).

- Learning to Learn [Paper](https://arxiv.org/pdf/1606.04474.pdf) | [Code](https://github.com/deepmind/learning-to-learn) — Google DeepMind, University of Oxford, Canadian Institute for Advanced Research
- [Model-Agnostic Meta-Learning for Fast Adaptation of Deep Networks](https://arxiv.org/abs/1703.03400) — Chelsea Finn, Pieter Abbeel, Sergey Levine
- [AutoML: Methods, Systems, Challenges](https://www.automl.org/book/) — Frank Hutter, Lars Kotthoff, Joaquin Vanschoren
- [Causal Reasoning from Meta-reinforcement Learning](https://arxiv.org/abs/1901.08162) — Ishita Dasgupta, Jane Wang, Silvia Chiappa, Jovana Mitrovic, Pedro Ortega, David Raposo, Edward Hughes, Peter Battaglia, Matthew Botvinick, Zeb Kurth-Nelson
- [The Evolved Transformer](https://arxiv.org/abs/1901.11117) — David R. So, Chen Liang, Quoc V. Le
- [Talos: Hyperparameter Scanning and Optimization for Keras](https://github.com/autonomio/talos) — Autonomio
- [EAT-NAS: Elastic Architecture Transfer for Accelerating Large-scale Neural Architecture Search](https://arxiv.org/abs/1901.05884) — Jiemin Fang, Yukang Chen, Xinbang Zhang, Qian Zhang, Chang Huang, Gaofeng Meng, Wenyu Liu, Xinggang Wang
- [FIGR: Few-shot Image Generation with Reptile](https://arxiv.org/abs/1901.02199) — Louis Clouâtre, Marc Demers
- Efficient Neural Architecture Search via Parameter Sharing [Paper](https://arxiv.org/abs/1802.03268) | [Code](https://github.com/melodyguan/enas) — Hieu Pham, Melody Y. Guan, Barret Zoph, Quoc V. Le, Jeff Dean
- Meta-Learning Shared Hierarchies [Paper](https://arxiv.org/abs/1710.09767) | [Blog](https://blog.openai.com/learning-a-hierarchy/) | [Code](https://github.com/openai/mlsh) — OpenAI
- [Learning Unsupervised Learning Rules](https://openreview.net/forum?id=HkNDsiC9KQ) — Luke Metz, Niru Maheswaranathan, Brian Cheung, Jascha Sohl-Dickstein
- [Reptile: A Scalable Meta-Learning Algorithm](https://github.com/openai/supervised-reptile) — Alex Nichol, John Schulman
- [Learning Shared Dynamics with Meta-World Models](https://arxiv.org/abs/1811.01741) — Lisheng Wu, Minne Li, Jun Wang
- [NIPS2017 Meta Learning Symposium videos](http://metalearning-symposium.ml/) — NIPS 2017
- [Colaboratory reimplementation of MAML in TF 2.0](https://colab.research.google.com/github/mari-linhares/tensorflow-maml/blob/master/maml.ipynb) — Marianne Linhares Monteiro

> "**_The notion of a neural "architecture" is going to disappear thanks to meta learning._**" — Andrew Trask

### __3. Environments__

#### __3.1 OpenAI Gym__

- OpenAI Gym [WebSite](https://gym.openai.com) | [Blog](https://blog.openai.com/openai-gym-beta/) | [GitHub](https://github.com/openai/gym) | [White Paper](http://arxiv.org/abs/1606.01540) — OpenAI

#### __3.2 Unity ML-Agents__

- Unity ML-Agents [WebSite](https://unity3d.ai) | [GitHub](https://github.com/Unity-Technologies/ml-agents) | [Documentation](https://github.com/Unity-Technologies/ml-agents/tree/master/docs) | [Challenge I](https://connect.unity.com/challenges/ml-agents-1) — Unity Technologies
- [Puppo, The Corgi: Cuteness Overload with the Unity ML-Agents Toolkit](https://blogs.unity3d.com/2018/10/02/puppo-the-corgi-cuteness-overload-with-the-unity-ml-agents-toolkit/) — Vincent-Pierre Berges, Leon Chen

#### __3.3 DeepMind Control Suite__

- DeepMind Control Suite [Paper](https://arxiv.org/abs/1801.00690) | [GitHub](https://github.com/deepmind/dm_control) | [Video](https://youtu.be/rAai4QzcYbs) — DeepMind

#### __3.4 Brigham Young University | Holodeck__

- BYU Holodeck: A high-fidelity simulator for deep reinforcement learning [Website](https://holodeck.cs.byu.edu) | [GitHub](https://github.com/byu-pccl/holodeck) | [Documentation](https://holodeck.readthedocs.io/en/latest/) — Brigham Young University

#### __3.5 Facebook's Horizon__

- Horizon: Facebook's Open Source Applied Reinforcement Learning Platform [Paper](https://arxiv.org/abs/1811.00260) | [GitHub](https://github.com/facebookresearch/Horizon) | [Blog](https://research.fb.com/publications/horizon-facebooks-open-source-applied-reinforcement-learning-platform/) — Jason Gauci, Edoardo Conti, Yitao Liang, Kittipat Virochsiri, Yuchen He, Zachary Kaden, Vivek Narayanan, Xiaohui Ye

#### __3.6 PhysX__

- PhysX SDK, an Open-Source Physics Engine [GitHub](https://github.com/NVIDIAGameWorks/PhysX-3.4) | [Blog](https://news.developer.nvidia.com/announcing-physx-sdk-4-0-an-open-source-physics-engine/?linkId=100000004228364) — NVIDIA

### __4. General Readings, Ressources and Tools__

- [Building safe artificial intelligence: specification, robustness, and assurance](https://medium.com/@deepmindsafetyresearch/building-safe-artificial-intelligence-52f5f75058f1) — Pedro A. Ortega, Vishal Maini, and the DeepMind safety team
- [Google Dataset Search Beta](https://toolbox.google.com/datasetsearch) — Google
- [Papers with Code](https://paperswithcode.com) — Papers with Code
- [GitXiv | arXiv + CODE](http://www.gitxiv.com) — Collaborative Open Computer Science
- [Best Paper Awards in Computer Science (since 1996)](https://jeffhuang.com/best_paper_awards.html) — Jeff Huang
- [The Vulnerable World Hypothesis](https://nickbostrom.com/papers/vulnerable.pdf) — Nick Bostrom
- [Podcast: Existential Hope in 2019 and Beyond](https://futureoflife.org/2018/12/21/podcast-existential-hope-in-2019-and-beyond/) — Ariel Conn
- Scalable agent alignment via reward modeling [Medium](https://medium.com/@deepmindsafetyresearch/scalable-agent-alignment-via-reward-modeling-bf4ab06dfd84) | [arXiv](https://arxiv.org/pdf/1811.07871.pdf) — Jan Leike, David Krueger, Tom Everitt, Miljan Martic, Vishal Maini, Shane Legg
- [The 2018 AI Index report](http://cdn.aiindex.org/2018/AI%20Index%202018%20Annual%20Report.pdf) — Yoav Shoham, Raymond Perrault, Erik Brynjolfsson, Jack Clark, James Manyika, Juan Carlos Niebles, Terah Lyons, John Etchemendy, Barbara Grosz, Zoe Bauer
- [ASILOMAR AI PRINCIPLES](https://futureoflife.org/ai-principles/) — The 2017 Asilomar conference
- [Strategic Implications of Openness in AI Development](https://nickbostrom.com/papers/openness.pdf) — Nick Bostrom

[![A Map of Ethical and Right-Based Approaches. Source: https://ai-hr.cyber.harvard.edu/primp-viz.html](../images/MapEthicalRightBasedApproaches.png "A Map of Ethical and Right-Based Approaches. Source: https://ai-hr.cyber.harvard.edu/primp-viz.html")](https://ai-hr.cyber.harvard.edu/primp-viz.html)

> "**_I believe that the answer here is to figure out how to create superintelligent A.I. such that even if -- when -- it escapes, it is still safe because it is fundamentally on our side because it shares our values. I see no way around this difficult problem._**" — Nick Bostrom

- [Artificial Intelligence and Human Rights](https://ai-hr.cyber.harvard.edu) — Jessica Fjeld, Hannah Hilligoss, Nele Achten, Maia Levy Daniel, Sally Kagay, and Joshua Feldman (Visualization Designed By: Arushi Singh)
- [teleportHQ ThinkToCode ecosystem](https://twitter.com/TeleportHQio/status/1043245039261044736) — teleportHQ
- [Statistical physics of liquid brains](https://www.biorxiv.org/content/biorxiv/early/2018/11/26/478412.full.pdf) — Jordi Pinero and Ricard Sole
- [Reframing Superintelligence](https://www.fhi.ox.ac.uk/wp-content/uploads/Reframing_Superintelligence_FHI-TR-2019-1.1-1.pdf) — K. Eric Drexler
- [Interpretable Machine Learning](https://christophm.github.io/interpretable-ml-book/) — Christoph Molnar
- [Building a Winning Self-Driving Car in Six Months](https://arxiv.org/abs/1811.01273) — Keenan Burnett, Andreas Schimpe, Sepehr Samavi, Mona Gridseth, Chengzhi Winston Liu, Qiyang Li, Zachary Kroeze, Angela P. Schoellig
- [Une intelligence artificielle bien réelle : les termes de l'IA](https://www.oqlf.gouv.qc.ca/ressources/bibliotheque/dictionnaires/vocabulaire-intelligence-artificielle.aspx) — Office québécois de la langue française
- [How to deliver on Machine Learning projects](https://blog.insightdatascience.com/how-to-deliver-on-machine-learning-projects-c8d82ce642b0) — Emmanuel Ameisen
- [The Malicious Use of Artificial Intelligence: Forecasting, Prevention, and Mitigation](https://arxiv.org/pdf/1802.07228.pdf) — Miles Brundage, Shahar Avin, Jack Clark, Helen Toner, Peter Eckersley, Ben Garfinkel, Allan Dafoe, Paul Scharre, Thomas Zeitzoff, Bobby Filar, Hyrum Anderson, Heather Roff, Gregory C. Allen, Jacob Steinhardt, Carrick Flynn, Seán Ó hÉigeartaigh, Simon Beard, Haydn Belfield, Sebastian Farquhar, Clare Lyle, Rebecca Crootof, Owain Evans, Michael Page, Joanna Bryson, Roman Yampolskiy, Dario Amodei
- [Machine Learning for Combinatorial Optimization: a Methodological Tour d'Horizon](https://arxiv.org/abs/1811.06128) — Yoshua Bengio, Andrea Lodi, Antoine Prouvost
- [26-Year-Old Nigerian Creates First Gaming Robot](https://www.ebony.com/news-views/26-year-old-nigerian-engineer-first-gaming-robot) — Christina Santi
- [Machine Learning Top 10 Articles for the Past Month (v.Oct 2018)](https://medium.mybridge.co/machine-learning-top-10-articles-for-the-past-month-v-oct-2018-ca24dadbe495) — Mybridge
- [Is artificial intelligence set to become art’s next medium?](https://www.christies.com/features/A-collaboration-between-two-artists-one-human-one-a-machine-9332-1.aspx) — Jonathan Bastable, Christie’s
- Phrase-Based & Neural Unsupervised Machine Translation [arXiv](https://arxiv.org/abs/1804.07755) | [Code](https://github.com/facebookresearch/UnsupervisedMT) | [Blog](https://code.fb.com/ai-research/unsupervised-machine-translation-a-novel-approach-to-provide-fast-accurate-translations-for-more-languages/) — Guillaume Lample, Myle Ott, Alexis Conneau, Ludovic Denoyer, Marc'Aurelio Ranzato
- [Tensor Considered Harmful](http://nlp.seas.harvard.edu/NamedTensor) — Alexander Rush
- [An Artificial Neuron Implemented on an Actual Quantum Processor](https://arxiv.org/abs/1811.02266) — Tacchino et al.
- [Efficiently measuring a quantum device using machine learning](https://arxiv.org/abs/1810.10042) — D.T. Lennon, H. Moon, L.C. Camenzind, Liuqi Yu, D.M. Zumbühl, G.A.D. Briggs, M.A. Osborne, E.A. Laird, N. Ares
- [Deep Learning : Current Limits and What Lies Beyond Them](https://youtu.be/2L2u303FAs8) — François Chollet
- [Open-ended Learning in Symmetric Zero-sum Games](https://arxiv.org/pdf/1901.08106.pdf) — David Balduzzi, Marta Garnelo, Yoram Bachrach, Wojtek Czarnecki, Julien Perolat, Max Jaderberg, Thore Graepel
- [Poker | Solving Imperfect-Information Games via Discounted Regret Minimization](hhttps://arxiv.org/abs/1809.04040) — Noam Brown, Tuomas Sandholm
- [Automatically Generating Comments for Arbitrary Source Code)](https://www.twosixlabs.com/automatically-generating-comments-for-arbitrary-source-code/) — Jessica Moore
- [The Illustrated BERT, ELMo, and co. (How NLP Cracked Transfer Learning)](https://jalammar.github.io/illustrated-bert/) — Jay Alammar
- [10 Exciting Ideas of 2018 in NLP](http://ruder.io/10-exciting-ideas-of-2018-in-nlp/) — Sebastian Ruder
- [Deconstructing BERT: Distilling 6 Patterns from 100 Million Parameters](https://towardsdatascience.com/deconstructing-bert-distilling-6-patterns-from-100-million-parameters-b49113672f77) — Jesse Vig
- [Learning to Infer Graphics Programs from Hand-Drawn Images](https://arxiv.org/abs/1707.09627) — Kevin Ellis, Daniel Ritchie, Armando Solar-Lezama, Joshua B. Tenenbaum
- [TensorFlow code and pre-trained models for BERT (Bidirectional Encoder Representations from Transformers)](https://github.com/google-research/bert) — Jacob Devlin, Ming-Wei Chang, Kenton Lee, Kristina Toutanova
- [The Superintelligent Will: Motivation and Instrumental Rationality in Advanced Artificial Agents](https://nickbostrom.com/superintelligentwill.pdf) — Nick Bostrom
- [MobiLimb: Augmenting Mobile Devices with a Robotic Limb](https://www.marcteyssier.com/projects/mobilimb/) — Marc Teyssier, Gilles Bailly, Catherine Pelachaud, Eric Lecolinet
- [32-Legged Spherical Robot Moves Like an Amoeba](https://spectrum.ieee.org/automaton/robotics/robotics-hardware/32-legged-spherical-robot-moves-like-an-amoeba) — Evan Ackerman, IEEE Spectrum
- [On winning all the big academic recent competitions. Presentation.](http://presentations.cocodataset.org/COCO17-Detect-Megvii.pdf) — Megvii (Face++) Team
- [Stanford AI recreates chemistry’s periodic table of elements](https://news.stanford.edu/2018/06/25/ai-recreates-chemistrys-periodic-table-elements/) — Ker Than
- [Neural Approaches to Conversational AI](https://arxiv.org/abs/1809.08267) — Jianfeng Gao, Michel Galley, Lihong Li
- [Learned optimizers that outperform SGD on wall-clock and validation loss](https://arxiv.org/abs/1810.10180) — Luke Metz, Niru Maheswaranathan, Jeremy Nixon, C. Daniel Freeman, Jascha Sohl-Dickstein
- [Beauty and the Beast: Optimal Methods Meet Learning for Drone Racing](https://arxiv.org/abs/1810.06224) — Elia Kaufmann, Mathias Gehrig, Philipp Foehn, René Ranftl, Alexey Dosovitskiy, Vladlen Koltun, Davide Scaramuzza
- [Writing Code for NLP Research](https://docs.google.com/presentation/d/17NoJY2SnC2UMbVegaRCWA7Oca7UCZ3vHnMqBV4SUayc/preview?slide=id.p) — Allen Institute for Artificial Intelligence
- [Autonomous Tidying-up Robot System](https://projects.preferred.jp/tidying-up-robot/en/) — Preferred Networks
- [Emerging Technology and Ethics Research Guide – v 1.0](https://danyaglabau.com/2018/11/05/emerging-technology-and-ethics-research-guide-v-1-0/) — Danya Glabau
- [Machine learning and artificial intelligence in the quantum domain](https://arxiv.org/abs/1709.02779) — Vedran Dunjko, Hans J. Briegel
- [Playing Mortal Kombat with TensorFlow.js. Transfer learning and data augmentation](https://blog.mgechev.com/2018/10/20/transfer-learning-tensorflow-js-data-augmentation-mobile-net/) — Minko Gechev
- [A series on quantum computing? Welcome to QuantumCasts!](https://youtu.be/hpHfzYTOMGI) — Marissa Giustina
- [NLP.js : a general natural language utilities for nodejs](https://github.com/axa-group/nlp.js) — AXA Shared Services Spain S.A.
- Hierarchical Multi-Task Learning model: One NLP model to rule them all! [Medium](https://medium.com/huggingface/beating-the-state-of-the-art-in-nlp-with-hmtl-b4e1d5c3faf) | [Demo](https://huggingface.co/hmtl/) | [Code](https://github.com/huggingface/hmtl/tree/master/demo) — Hugging Face
- [Constructing exact representations of quantum many-body systems with deep neural networks](https://arxiv.org/pdf/1802.09558.pdf) — Giuseppe Carleo
- [Over 200 of the Best Machine Learning, NLP, and Python Tutorials — 2018 Edition](https://medium.com/machine-learning-in-practice/over-200-of-the-best-machine-learning-nlp-and-python-tutorials-2018-edition-dd8cf53cb7dc) — Robbie Allen
- [Deep Learning Papers Reading Roadmap](https://github.com/floodsung/Deep-Learning-Papers-Reading-Roadmap) — Flood Sung
- [Learn Machine Learning from Top 50 Articles for the Past Year (v.2019)](https://medium.mybridge.co/learn-machine-learning-from-top-50-articles-for-the-past-year-v-2019-15842d0b82f6) — Mybridge
- [Open Courses and Textbooks](https://sgfin.github.io/learning-resources/) — Samuel G. Finlayson
- [~250 awesome short lectures on robotics](https://robotacademy.net.au) — Queensland University of Technology Robot Academy
- [The Best Textbooks on Every Subject](https://www.lesswrong.com/posts/xg3hXCYQPJkwHyik2/the-best-textbooks-on-every-subject) — lukeprog

> "**_ML paper writing pro-tip: you can download the raw source of any arxiv paper. Click on the "Other formats" link, then click "Download source". This gets you a .tar.gz with all the .tex files, all the image files for the figures in their original resolution, etc._**" — Ian Goodfellow

***

### __Deep Reinforcement Learning with OpenAI Gym 101__

On **Sat, February 13, 2021 | 10:00 AM – 11:30 AM EST**, the __General Secretariat of MONTREAL.AI__ will present: "__*Deep Reinforcement Learning with OpenAI Gym 101*__".

<a href="https://reinforcementlearning101.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Deep Reinforcement Learning with OpenAI Gym 101 : Buy Tickets on Eventbrite</a>

[![Online Event: Deep Reinforcement Learning with OpenAI Gym 101](../images/RL101Webinarv19.jpg "Online Event: Deep Reinforcement Learning with OpenAI Gym 101")](https://reinforcementlearning101.eventbrite.ca)

<div id="eventbrite-widget-container-117727240345"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117727240345',
        iframeContainerId: 'eventbrite-widget-container-117727240345',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Language:__ Tutorial (webinar) given in __English__.

> "**_Intelligence is the computational part of the ability to predict and control a stream of experience._**" — Rich Sutton

__Location: This is an online event.__ This is a live streamed webinar with interaction with and among students. *Attendees will receive instructions on how to access the live stream at __9:45 AM (EST) on Sat, Feb. 13, 2021__.*

***

## __Customized Artificial Intelligence Training for Businesses__

### Organizations Adopting New AI Tools Need to Develop Internal Skills

[![Customized Artificial Intelligence Training for Businesses](../images/consulting1920v1.jpg "Customized Artificial Intelligence Training for Businesses")](mailto:secretariat@montreal.ai?subject=Customized%20Artificial%20Intelligence%20Training%20for%20Businesses)

__QUÉBEC.AI__ provides made-to-measure training programs in digital intelligence for select organizations.

__For any questions about our made-to-measure training programs in digital intelligence :__

​​✉️ __Email Us__ : info@quebec.ai
​📞 __Phone__ : +1.514.829.8269
​🌐 __Website__ : http://www.quebec.ai
​📝 __LinkedIn__ : https://www.linkedin.com/in/quebecai
​🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Administrative Head Office*
​
#__AI101__ #__AIFirst__ #__QuebecAI__ #__QuebecAIAcademy__ #__QuebecArtificialIntelligence__
