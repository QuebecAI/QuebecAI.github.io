---
title: Québec Artificial Intelligence
---
## Montréal.AI Academy : AI 101

__AI 101 : The Dawn of Artificial Intelligence__

[![AI 101 : The First Comprehensive Overview of AI for the General Public](../images/academy1920cover_v0.jpg "AI 101 : The First Comprehensive Overview of AI for the General Public")](http://montreal.ai/academy.pdf)

## The First Comprehensive Overview of AI for the General Public

__AI 101 : A Well-Crafted Actionable 75 Minutes Tutorial__

POWERFUL & USEFUL. This actionable tutorial is designed to entrust everybody with the mindset, the skills and the tools to see artificial intelligence from an empowering new vantage point by :

— Exalting state of the art discoveries and science ;
— Curating the best open-source codes & implementations ; and
— Embodying the impetus that drives today’s artificial intelligence.

Montréal.AI is the largest artificial intelligence community in Canada. **_Join us and learn_** at https://www.facebook.com/groups/MontrealAI/ !

## #AI4Artists : Unveilling a World of Hidden Secrets

__Pioneering Legendary Creations__

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Vincent Boucher, B. Sc. Theoretical Physics, M. A. Government Policy Analysis and M. Sc. Aerospace Engineering and Founding Chairman of Montréal.AI

Designed for artists, _#AI4Artists_ is created to inspire artists who, with AI, will shape the 21st Century.

[![AI4Artists : The First Comprehensive Overview of All (全) AI for Artists](../images/AI4ArtistsProgram_v4.jpg "AI4Artists : The First Comprehensive Overview of All (全) AI for Artists")](http://www.montreal.ai/AI4Artists.pdf)

<p data-height="265" data-theme-id="dark" data-slug-hash="gzjgEP" data-default-tab="js,result" data-user="teropa" data-embed-version="2" data-pen-title="Robot Neil's Bubble Bath" class="codepen">See the Pen <a href="https://codepen.io/teropa/pen/gzjgEP/">Robot Neil's Bubble Bath</a> by Tero Parviainen (<a href="https://codepen.io/teropa">@teropa</a>) on <a href="https://codepen.io">CodePen</a>.</p>
<script async src="https://static.codepen.io/assets/embed/ei.js"></script>

###### ＊ _This 75 minutes tutorial is presently in alpha, with a limited number of  customers to help us refine it. As we enter beta, we'll take on many more groups (minimum 150 persons) from the waiting list._

![AI4Artists : The First Comprehensive Overview of All (全) AI for Artists](../images/13Feb2011ai360_1920.jpg "AI4Artists : The First Comprehensive Overview of All (全) AI for Artists")

✉️ Group Reservation : academy@montreal.ai
🌐 Website : http://www.academy.montreal.ai/

#__AI__ #__AIFirst__ #__MontrealAI__ #__MontrealAIAcademy__ #__MontrealArtificialIntelligence__
