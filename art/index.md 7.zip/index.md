---
title: MONTRÉAL.AI | Montréal Artificial Intelligence
---
## MONTRÉAL.AI FINE ARTS (Pre-Release Early Version)

__Creating Fine AI Arts History | Quintessential Launches in Major Cities!__

*Quebec, Montreal, Vancouver, San Maarten, Beverly Hills, Caesar’s, Panama, Brasil, Paris, Milano, Principauté de Monaco, Geneva, Belgium, Germany, Luxembourg, Spain, Austria, London, Russian Federation, Aspen, Maui, SoHo, Israel, La Jolla, Macau, Dubai, India, Qatar, Saudi Arabia, Beijing, Shanghai, Hong Kong, Tokyo Midtown and Tapei.*

__Pioneering Legendary Fine AI Arts — Montréal.AI is Presenting a New World Age of Artistic Visions.__

<p align="center">
![The Scent of AI (Perfume) — Signed: Montreal.AI](../images/26eb011ai-v0.jpg "The Scent of AI (Perfume) — Signed: Montreal.AI")
</p>

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Montréal.AI Fine Arts

__A blending of Art, Culture, and Science in the spirit of Leonardo da Vinci.__

Opening the doors to the AI art movement of the 21st Century, __Montréal.AI Fine Arts__ is causing a huge stir amongst top art collectors and the most brilliant, influential, and iconoclastic figures worldwide.

During the Renaissance, __Pope Julius II__ commissioned painter __Michelangelo__ for artwork of the __Sistine Chapel__ ceiling at the Vatican. Today, you may commission AI artwork from __The House of Montréal.AI Fine Arts__.

Captivating a discerning audience, __Montréal.AI Fine Arts__ reflects the *aesthetic diversity, conceptual richness and ‘purist’ form of AI creativity expressed by the machine* and is regarded as the highest in the hierarchy of genres. We are preparing a worldwide PR campaing with major __talk show__ appearances and a __TV documentary__.

## A New Day Has Come in Art Industry

__Fine AI Art-market history__ was made on October 25, 2018 when the first artificial intelligence artwork ever sold at Christie’s auction house shattered expectations, fetching $432,500.

![Edmond de Belamy, from La Famille de Belamy](../images/Edmond_de_Belamy_from_La_Famille_de_Belamy.png "Edmond de Belamy, from La Famille de Belamy")

### References

- [The first AI artwork to be sold in a major auction achieves $432,500 after a bidding battle on the phones and via ChristiesLive](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee) — Christie's
- [A sign of things to come? AI-produced artwork sells for $433K, smashing expectations](https://edition.cnn.com/style/article/obvious-ai-art-christies-auction-smart-creativity/index.html) — Allyssia Alleyne, CNN
- [Eerie AI-generated portrait fetches $432,500 at auction](https://techcrunch.com/2018/10/26/eerie-ai-generated-portrait-fetches-432500-at-auction/) — Devin Coldewey, TechCrunch

> "**_A spokesperson from Christie's told us of the market's excitement as this significant shift. "We can confirm there were 5 different bidders from all parts of the world competing for this lot at that high price level, which seems a good indication of collector interest and future market potential for AI art generally..."_**" — Adam Heardman, MutualArt

## The House of Montréal.AI Fine Arts

__Fine AI Arts History & Heritage: The Building of a Legacy__

__*Montréal.AI Fine Arts*__ is ahead of a trend that will profoundly impact the $350 billion / Year international fashion, fine arts & jewelry industry ( 🌐 http://www.billionaire.tv/TheGazette.pdf ).

__A Renewal of the High Renaissance Ideals.__ | __*Montréal.AI Fine Arts*__ artificial intelligence agents learn from experience to create superhuman artworks and artistic visions! Our creations are pure object of désirs, fairytale lands and enchanted dreams conveying a feeling of exclusiveness : *A fascinating, provocative and vibrant AI poetry*.

![Unveiling a majestic world of hidden secrets...](../images/h355ai1440.jpg "Unveiling a majestic world of hidden secrets...")

Harnessing the __*Deep Learning*__, __*Deep Reinforcement Learning*__, __*Generative Adversarial Nets*__, __*Meta-Learning*__ and __*Self-Play*__ on a truly global scale and deploying a passion offering insight with unusual breadth of elegance, refinement and style, __*The House of Montréal.AI Fine Arts*__ pioneers unmistakable AI-generated superhuman creations and revolutionary designs, unveiling a majestic world of hidden secrets:

__❖ The Scent of AI (Perfumes)__
A line as enchanting as the muses it inspires.

__❖ Many-Worlds AI High Jewelry ( 💎 )__
*AI is poised to define the diamond industry of the 21st century.*
__The House of Montreal.AI Fine Arts__ is pioneering *AI Diamond cuts* with an unprecedented culmination of brilliance, scintillation and dispersion for the Fashionees who will set the high jewelry trends of our era.

__❖ AI Artworks (Signed: Montreal.AI)__
Numbered and signed original prints including certificate of authenticity.

![Unveiling a majestic world of hidden secrets...](../images/AIDiamond.mp4 "Unveiling a majestic world of hidden secrets...")

An odyssey of cosmological, divine and mythological parallel universes of AI lullabies. 

### A Legendary History: The Source of an Exceptional Legacy

__From: The General Secretariat of the Montréal.AI Fine Arts Executive Council__

A professional skilled catalyst versed in innovative research, high financial engineering and international luxury scene, __Montreal.AI's Founding Chairman Vincent Boucher__ received, on the 15th of October 2009, the prestigious __Guinness World Records__ title for his Largest Cut Paraiba Tourmaline.

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf](../images/GuinnessWorldRecordsCertificate.jpg "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

__A Work of Intellectual, Aesthetic and Technical Innovation__ | Vincent Boucher’s strategic foresight and ability to drive one of the most ambitious projects in History has pushed this highly experienced and seasoned human being to the forefront of its field, earning a well-deserved reputation on a truly global scale.

[![Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.](../images/TheGazetteBusinessFrontPage.tif "Montreal.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.]")](http://www.billionaire.tv/TheGazette.pdf)

> "**_Financier (Vincent Boucher) acquires world’s rarest stone."_**" — Mike King, The Gazette

[![Guinness World Records™ | It's a gem of a start for Billionaire](../images/mosaic.tif "Guinness World Records™ | It's a gem of a start for Billionaire")](http://www.billionaire.tv/TheGazette.pdf)

Exalting the purest and most beautiful creations, offering education and research revealing a unique range of critical, intellectual, and historical point of view, and opening the doors to a New Art Movement, __*The House of Montréal.AI Fine Arts*__ fuels, with authority, the passion that drive today’s most successful AI artists.

## Defining the Genre of AI-Made Fine Art

__A Sense of Mystery... And Deep Understanding of the World, People and Human Nature.__

![Principia of The Grand Design: Montréal.AI Fine Arts believes in seamlessly seing relationships that matter](../images/ExTradingUniverseTwoMay18HD1080-v0.mp4 "Principia of The Grand Design: Montréal.AI Fine Arts believes in seamlessly seing relationships that matter")

> "**_To identify truly path-breaking work, we would do better to stop asking where the boundary line lies between human artists’ agency and that of AI toolsets, and instead start asking whether human artists are using AI to plumb greater conceptual and aesthetic depths than researchers or coders._**" — Tim Schneider and Naomi Rea, artnet, September 25, 2018

__Deep Learning + Deep Reinforcement Learning + Generative Adversarial Nets + Meta-Learning + Self-Play__

### References

- [Data Science, Machine Learning and Artificial Intelligence for Art](https://towardsdatascience.com/data-science-machine-learning-and-artificial-intelligence-for-art-1ac48c4fad41) — Vishal Kumar
- [Scaling the Mission: The Met Collection API (406,000 images of over 205,000 CC0 objects)](https://www.metmuseum.org/blogs/now-at-the-met/2018/met-collection-api) — Loic Tallon, Chief Digital Officer
- [What do 50 million drawings look like?](https://quickdraw.withgoogle.com/data) — Google
- [Neural scene rendering: Transfer learning to render a fruit still life from photos](https://docs.google.com/presentation/d/182KZT1Qg1rY8qnroDytn-4z5ODFjNSYkfNlwbDJAI-o/edit#slide=id.g35f391192_00) — Brett Göhre
- GAN Lab: Play with Generative Adversarial Networks (GANs) in your browser! [Web](https://poloclub.github.io/ganlab/) | [Paper](https://minsuk.com/research/papers/kahng-ganlab-vast2018.pdf) — Minsuk Kahng, Nikhil Thorat, Polo Chau, Fernanda Viégas, and Martin Wattenberg
- [Generating Memoji from Photos](https://patniemeyer.github.io/2018/10/29/generating-memoji-from-photos.html) — Pat Niemeyer
- [Playing a game of GANstruction](https://thegradient.pub/playing-a-game-of-ganstruction/) — Helena Sarin
- Large Scale GAN Training for High Fidelity Natural Image Synthesis [Paper](https://arxiv.org/abs/1809.11096) | [TF Hub](https://tfhub.dev/s?q=biggan) | [Colab](https://colab.research.google.com/github/tensorflow/hub/blob/master/examples/colab/biggan_generation_with_tf_hub.ipynb) — Andrew Brock, Jeff Donahue, Karen Simonyan
- [TL-GAN: transparent latent-space GAN](https://github.com/SummitKwan/transparent_latent_gan) — SummitKwan
- [TensorFlow-GAN (TFGAN)](https://github.com/tensorflow/tensorflow/tree/master/tensorflow/contrib/gan) — Joel Shor, Sergio Guadarrama
- [Progressive GANs | Notebook with smooth interpolations through z-space](https://github.com/genekogan/progressive_growing_of_gans/blob/master/generate.ipynb) — Gene Kogan
- Self-Attention GAN [Paper](https://arxiv.org/abs/1805.08318) | [Tensorflow implementation](https://github.com/brain-research/self-attention-gan) — Han Zhang, Ian Goodfellow, Dimitris Metaxas, Augustus Odena
- [Discriminator Rejection Sampling](https://arxiv.org/abs/1810.06758) — Samaneh Azadi, Catherine Olsson, Trevor Darrell, Ian Goodfellow, Augustus Odena
- [Tensorpack | Generative Adversarial Networks](https://github.com/tensorpack/tensorpack/tree/master/examples/GAN) — Tensorpack
- [Ngx | Neural network based visual generator and mixer](https://github.com/keijiro/Ngx) — Keijiro Takahashi
- [Magenta Studio (beta)](https://magenta.tensorflow.org/studio) — Google AI
- [Differentiable Monte Carlo Ray Tracing through Edge Sampling](https://people.csail.mit.edu/tzumao/diffrt/) — Tzu-Mao Li, Miika Aittala, Frédo Durand, Jaakko Lehtinen
- [A Few Unusual Autoencoders](https://colinraffel.com/talks/vector2018few.pdf) — Colin Raffel
- [Deep Variational Reinforcement Learning for POMDPs](https://arxiv.org/abs/1806.02426) — Maximilian Igl, Luisa Zintgraf, Tuan Anh Le, Frank Wood, Shimon Whiteson
- [Learning Dexterity](https://blog.openai.com/learning-dexterity/) — OpenAI
- [Robots that Learn](https://blog.openai.com/robots-that-learn/) — OpenAI
- [(Self-Play) | OpenAI Five](https://blog.openai.com/openai-five/) — OpenAI
- [TFHub state-of-the-art AutoAugment Modules](https://tfhub.dev/s) — TensorFlow
- [Creatability: a new collection of experiments exploring ways to make creative tools more accessible](https://g.co/creatability) — Experiments with Google
- [Evolved Virtual Creatures, Evolution Simulation, 1994](https://youtu.be/JBgG_VSP7f8) — Karl Sims
- Reinforcement Learning for Improving Agent Design: What happens when we let an agent learn a better body design together with learning its task? [Article](https://designrl.github.io/) | [Paper](https://arxiv.org/abs/1810.03779 ) — David Ha

> "**_The defining art-making technology of our era will be AI._**" — Rama Allen

## #AI4Artists : Unveilling a World of Hidden Secrets

__Pioneering Legendary Creations :  A Well-Crafted 75 Minutes Tutorial  for Artists__

[![Pioneering Legendary Creations : 75 Minutes Tutorial](../images/AI4ArtistsP1.jpg "#AI4Artists : Unveilling a World of Hidden Secrets")](http://www.montreal.ai/AI4Artists.pdf)
<a href="https://www.eventbrite.ca/e/montrealai-academy-artificial-intelligence-for-artists-ai4artists-tickets-52966101034?ref=ebtn" target="_blank"><img src="https://www.eventbrite.ca/custombutton?eid=52966101034" alt="Eventbrite - Montréal.AI Academy: Artificial Intelligence for Artists #AI4Artists" /></a>

__Who do you turn to if you seek out to learn the very best in AI for Artists?__

Encompassing all facets of AI for Artists, the General Secretariat of MONTREAL.AI introduces, with authority and insider knowledge: "__*#AI4Artists: First World-Class Overview of AI for Artists*__".

__POWERFUL & USEFUL.__ This actionable tutorial is designed to entrust every person who creates art with the mindset, the skills and the tools to see artificial intelligence from an empowering new vantage point by :

— Exalting state of the art discoveries and science ;
— Curating the best open-source codes & implementations ; and
— Embodying the impetus that drives today’s artificial intelligence.

Designed for artists, [__*#AI4Artists*__](http://www.montreal.ai/AI4Artists.pdf) is created to inspire artists who, with AI, will shape the 21st Century.

<div style="width:100%; text-align:left;"><iframe src="https://eventbrite.ca/tickets-external?eid=52966101034&ref=etckt" frameborder="0" height="445" width="100%" vspace="0" hspace="0" marginheight="5" marginwidth="5" scrolling="auto" allowtransparency="true"></iframe><div style="font-family:Helvetica, Arial; font-size:12px; padding:10px 0 5px; margin:2px; width:100%; text-align:left;" ><a class="powered-by-eb" style="color: #ADB0B6; text-decoration: none;" target="_blank" href="https://www.eventbrite.ca/">Powered by Eventbrite</a></div></div>

## A Truly Special Celebration that is Certain to Make History!

For Andre Breton, the father of surrealism, the purpose of Art is the unification of the real and the imaginary. __Montréal.AI Fine Arts__ makes Breton’s dream come true. A truly special celebration in the world of fine arts, fashion and high jewelry and one that is certain to make history!

*We are looking for Ambassadors & Partners.*

✉️ __Email Us__ : info@montreal.ai
📞 __Phone__ : +1.514.829.8269
🌐 __Website__ : http://www.montreal.ai
📝 __LinkedIn__ : https://www.linkedin.com/in/montrealai
🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Executive Council and Administrative Head Office*

#__AIFirst__ #__MontrealAI__ #__MontrealAIArt__ #__MontrealArtificialIntelligence__
