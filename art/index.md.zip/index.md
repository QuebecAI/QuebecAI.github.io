---
title: QUÉBEC.AI | Québec Artificial Intelligence
---
## **QUÉBEC.AI FINE ARTS (_Pre-Release Early Version_)**

### Get Ready for the Launch!

__Creating Fine AI Arts History | Quintessential Launches in Major Cities!__

*Quebec, Montreal, Vancouver, San Maarten, Beverly Hills, Caesar’s, Panama, Brasil, Paris, Milano, Principauté de Monaco, Geneva, Belgium, Germany, Luxembourg, Spain, Austria, London, Russian Federation, Aspen, Maui, SoHo, Israel, La Jolla, Macau, Dubai, India, Qatar, Saudi Arabia, Beijing, Shanghai, Hong Kong, Tokyo Midtown and Tapei.*

__Pioneering Legendary Creations : Québec.AI is Presenting a New World Age of Artistic Visions.__

![Unveiling a majestic world of hidden secrets...](../images/AITrillion1440.jpg "Unveiling a majestic world of hidden secrets...")

### A blending of Art and Science in the spirit of Leonardo da Vinci.

Opening the doors to the AI art movement of the 21st Century, __Québec.AI Fine Arts__ is causing a huge stir amongst top art collectors and the most brilliant, influential, and iconoclastic figures worldwide.

Captivating a discerning audience, __Québec.AI Fine Arts__ reflects the *aesthetic diversity, conceptual richness and ‘purist’ form of AI creativity expressed by the machine* and is regarded as the highest in the hierarchy of genres. We are preparing a worldwide PR campaing with major __talk show__ appearances and a __TV documentary__.

***

## **Québec.AI Academy Presents:** _**AI 101 for Artists**_

[![Pioneering Legendary Creations : 75 Minutes Tutorial](../images/ExTradingUniverseTwoMay18HD1080-v0.mp4 "#AI4Artists : Unveilling a World of Hidden Secrets")](http://www.montreal.ai/AI4Artists.pdf)

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Québec.AI Fine Arts

### A Well-Crafted 75 Minutes Tutorial  for Artists

**Encompassing all facets of AI for Artists**, the House of QUÉBEC.AI Fine Arts introduces, with authority and insider knowledge: "__*Artificial Intelligence for Artists: The First World-Class Overview of AI for Artists*__".

__Program:__ [*"Unveilling a World of Hidden Secrets"*](http://www.montreal.ai/AI4Artists.pdf)

__Group Reservation__ : secretariat@montreal.ai

Designed for artists, [__*#AI4Artists*__](http://www.montreal.ai/AI4Artists.pdf) is created to inspire sentient beings who will shape the 21st Century.

> "**_To identify truly path-breaking work, we would do better to stop asking where the boundary line lies between human artists’ agency and that of AI toolsets, and instead start asking whether human artists are using AI to plumb greater conceptual and aesthetic depths than researchers or coders._**" — Tim Schneider and Naomi Rea, artnet, September 25, 2018

***

## __AI CONCERT : Defining the Genre of AI-Made Music__

### **MONTREAL.AI Orchestra:** Pioneering Superhuman Symphonies

[![MONTREAL.AI Orchestra: Pioneering Superhuman Symphonies](../images/AIConcert1440x2880v2.jpg "MONTREAL.AI Orchestra: Pioneering Superhuman Symphonies")](https://aiconcert.eventbrite.ca)

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## A New Day Has Come in Art Industry

__Fine AI Art-market history__ was made on October 25, 2018 when the first artificial intelligence artwork ever sold at Christie’s auction house shattered expectations, fetching $432,500.

![Edmond de Belamy, from La Famille de Belamy](../images/Edmond_de_Belamy_from_La_Famille_de_Belamy.png "Edmond de Belamy, from La Famille de Belamy")

### References

- [The first AI artwork to be sold in a major auction achieves $432,500 after a bidding battle on the phones and via ChristiesLive](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee) — Christie's
- [A sign of things to come? AI-produced artwork sells for $433K, smashing expectations](https://edition.cnn.com/style/article/obvious-ai-art-christies-auction-smart-creativity/index.html) — Allyssia Alleyne, CNN
- [Eerie AI-generated portrait fetches $432,500 at auction](https://techcrunch.com/2018/10/26/eerie-ai-generated-portrait-fetches-432500-at-auction/) — Devin Coldewey, TechCrunch

> "**_A spokesperson from Christie's told us of the market's excitement as this significant shift. "We can confirm there were 5 different bidders from all parts of the world competing for this lot at that high price level, which seems a good indication of collector interest and future market potential for AI art generally..."_**" — Adam Heardman, MutualArt

***

## The House of Québec.AI Fine Arts

__Fine AI Arts History & Heritage: The Building of a Legacy__

__*Québec.AI Fine Arts*__ is ahead of a trend that will profoundly impact the $350 billion / Year international fashion, fine arts & jewelry industry ( 🌐 http://www.billionaire.tv/TheGazette.pdf ).

__A Renewal of the High Renaissance Ideals.__ | __*Québec.AI Fine Arts*__ artificial intelligence agents learn from experience to create superhuman artworks and artistic visions! Our creations are pure object of désirs, fairytale lands and enchanted dreams conveying a feeling of exclusiveness : *A fascinating, provocative and vibrant AI poetry*.

Harnessing the __*Deep Learning*__, __*Deep Reinforcement Learning*__, __*Generative Adversarial Nets*__, __*Meta-Learning*__ and __*Self-Play*__ on a truly global scale and deploying a passion offering insight with unusual breadth of elegance, refinement and style, __*The House of Québec.AI Fine Arts*__ pioneers unmistakable AI-generated superhuman creations and revolutionary designs, unveiling a majestic world of hidden secrets:

__❖ The Scent of AI (Perfumes)__
A line as enchanting as the muses it inspires.

<p align="center">
![The Scent of AI (Perfume) — Signed: Québec.AI](../images/26eb011ai-v0.jpg "The Scent of AI (Perfume) — Signed: Québec.AI")
</p>

__❖ Many-Worlds AI High Jewelry ( 💎 )__
*AI is poised to define the diamond industry of the 21st century.*

![Unveiling a majestic world of hidden secrets...](../images/AIDiamond.mp4 "Unveiling a majestic world of hidden secrets...")

__The House of Québec.AI Fine Arts__ is pioneering *AI Diamond cuts* with an unprecedented culmination of brilliance, scintillation and dispersion for the Fashionees who will set the high jewelry trends of our era.

__❖ AI Artworks (Signed: Québec.AI)__
Numbered and signed original prints including certificate of authenticity.

An odyssey of cosmological, divine and mythological parallel universes of AI lullabies. 

### A Legendary History: The Source of an Exceptional Legacy

__From: The General Secretariat of the Québec.AI Fine Arts Executive Council__

A professional skilled catalyst versed in innovative research, high financial engineering and international luxury scene, __Québec.AI's Founding Chairman Vincent Boucher__ received, on the 15th of October 2009, the prestigious __Guinness World Records__ title for his Largest Cut Paraiba Tourmaline.

[![Québec.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf](../images/GuinnessWorldRecordsCertificate.jpg "Québec.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry: http://www.billionaire.tv/TheGazette.pdf]")](http://www.billionaire.tv/TheGazette.pdf)

__A Work of Intellectual, Aesthetic and Technical Innovation__ | Vincent Boucher’s strategic foresight and ability to drive one of the most ambitious projects in History has pushed this highly experienced and seasoned human being to the forefront of its field, earning a well-deserved reputation on a truly global scale.

[![Québec.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.](../images/TheGazetteBusinessFrontPage.tif "Québec.AI's Chairman Vincent Boucher holds a Guinness World Records in the fine arts and high jewelry industry.]")](http://www.billionaire.tv/TheGazette.pdf)

> "**_Financier (Vincent Boucher) acquires world’s rarest stone."_**" — Mike King, The Gazette

[![Guinness World Records™ | It's a gem of a start for Billionaire](../images/mosaic.tif "Guinness World Records™ | It's a gem of a start for Billionaire")](http://www.billionaire.tv/TheGazette.pdf)

Exalting the purest and most beautiful creations, offering education and research revealing a unique range of critical, intellectual, and historical point of view, and opening the doors to a New Art Movement, __*The House of Québec.AI Fine Arts*__ fuels, with authority, the passion that drive today’s most successful AI artists.

***

## A Truly Special Celebration that is Certain to Make History!

During the Renaissance, __Pope Julius II__ commissioned painter __Michelangelo__ for artwork of the __Sistine Chapel__ ceiling at the Vatican. Today, you may commission AI artwork from __The House of Québec.AI Fine Arts__.

> "**_The defining art-making technology of our era will be AI._**" — Rama Allen

For Andre Breton, the father of surrealism, the purpose of Art is the unification of the real and the imaginary. __Québec.AI Fine Arts__ makes Breton’s dream come true. A truly special celebration in the world of fine arts, fashion and high jewelry and one that is certain to make history!

*We are looking for Ambassadors & Partners.*

​​✉️ __Email Us__ : info@quebec.ai
​📞 __Phone__ : +1.514.829.8269
​🌐 __Website__ : http://www.quebec.ai
​📝 __LinkedIn__ : https://www.linkedin.com/in/quebecai
​🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Administrative Head Office*
​
#__AIFirst__ #__QuebecAI__ #__QuebecAIArt__ #__QuebecArtificialIntelligence__
