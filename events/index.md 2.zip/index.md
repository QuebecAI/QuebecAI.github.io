---
title: QUÉBEC.AI | Québec Artificial Intelligence
---
## **QUÉBEC.AI EVENTS**

### **Salon | Press Dinner | Concert | Art Auction | Charity Gala**

![Québec.AI Events](../images/QuebecAIv6WhatIsAI1440x1440.jpg "Québec.AI Events")

***

## **❖ QUÉBEC.AI World-Class Events**

### _SEMINAL DEBATE : Yoshua Bengio | Gary Marcus_

[![QUÉBEC.AI World-Class Events — SEMINAL DEBATE : Yoshua Bengio | Gary Marcus](../images/bengio-marcus.jpg "QUÉBEC.AI World-Class Events — SEMINAL DEBATE : Yoshua Bengio | Gary Marcus")](https://bengio-marcus.eventbrite.ca)

**This Is The Debate The AI World Has Been Waiting For**

Date and Time : December 23, 2019 | 7:00 PM – 8:30 PM EST

LIVE STREAMING : https://bengio-marcus.eventbrite.ca

<div id="eventbrite-widget-container-81620778947"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '81620778947',
        iframeContainerId: 'eventbrite-widget-container-81620778947',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

**QUÉBEC.AI** is grateful to **Mila - Institut Québécois d'Intelligence Artificielle** and to the collaborative Montreal AI ecosystem. A special thanks to Sasha Lu for her decisive involvement.

***

## **❖ QUÉBEC.AI Captains of AI Industries Celebration**

### _Honoring Award-Winning Captains of AI Industries & Luminaries_

***

## **❖ QUÉBEC.AI Press Dinner**

### _Honoring Award-Winning AI Journalism_

***

## **❖ QUÉBEC.AI's Fine Arts Auction**

### _Unveilling a World of Hidden Secrets..._

![QUÉBEC.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...](../images/AITrillion1440.jpg "QUÉBEC.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...")

On October 25, 2018, [the first artificial intelligence artwork ever sold at Christie’s auction house shattered expectations, fetching $432,500](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Today, the _House of Québec.AI Fine Arts_ introduces : _Québec.AI's Fine Arts Auction_, the **first international auction dedicated to quintessential fine AI arts**.

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Québec.AI Fine Arts

We are getting ready for the first auction. Top art collectors will be able to place bids internationally.

***

## **❖ QUÉBEC.AI Salon**

### _Gathering of People Under the Roof of an Inspiring Host_

***

## **❖ QUÉBEC.AI Academy : AI 101**

### _Pioneering an Impactful Understanding of AI_

### **AI 101: For the Newcomers to Artificial Intelligence!**

On **Tue, Nov 26, 2019 | 6:30 PM - 8:30 PM EST**, the __General Secretariat of QUÉBEC.AI__ will present, with authority: "__*Artificial Intelligence 101: The First World-Class Overview of AI for the General Public*__".

__Location: NRH Prince Arthur - Ballroom, 3625 Avenue du Parc, Montreal (Québec), Canada, H2X 3P8.__
<!-- Noscript content for added SEO -->
<noscript><a href="https://ai101montreal.eventbrite.ca" rel="noopener noreferrer" target="_blank"></noscript>
<!-- You can customize this button any way you like -->
<button id="eventbrite-widget-modal-trigger-68213946751" type="button">Artificial Intelligence 101 : Buy Tickets on Eventbrite</button>
<noscript></a>Buy Tickets on Eventbrite</noscript>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        widgetType: 'checkout',
        eventId: '68213946751',
        modal: true,
        modalTriggerElementId: 'eventbrite-widget-modal-trigger-68213946751',
        onOrderComplete: exampleCallback
    });
</script>

[![Artificial Intelligence 101: The First World-Class Overview of AI for the General Public](../images/InvitationLetter26Nov2019v2.jpg "Artificial Intelligence 101: The First World-Class Overview of AI for the General Public")](https://ai101montreal.eventbrite.ca)

> "**_(AI) will rank among our greatest technological achievements, and everyone deserves to play a role in shaping it._**" — Fei-Fei Li

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Tickets:__ https://ai101montreal.eventbrite.ca

__Language:__ Tutorial given in __English__.
__Date And Time:__ Tue, 26 November 2019 | 6:30 PM – 8:30 PM EST
__Location: NRH Prince Arthur - Ballroom, 3625 Avenue du Parc, Montreal (Québec), Canada, H2X 3P8.__

<div id="eventbrite-widget-container-68213946751"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '68213946751',
        iframeContainerId: 'eventbrite-widget-container-68213946751',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ QUÉBEC.AI's Fireside Chat**

***

## **❖ QUÉBEC.AI's Ambassadors Dinner**

***

## **❖ QUÉBEC.AI Orchestra**

### _Pioneering Superhuman Symphonies_

[![QUÉBEC.AI Orchestra: Pioneering Superhuman Symphonies](../images/AIConcert1440x2880v2.jpg "QUÉBEC.AI Orchestra: Pioneering Superhuman Symphonies")](https://aiconcert.eventbrite.ca)

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ QUÉBEC.AI Philanthropic Award Gala**

> "**_It's springtime for AI, and we're anticipating a long summer._**" — Bill Braun, CIO of Chevron

​​✉️ __Email Us__ : info@quebec.ai
​📞 __Phone__ : +1.514.829.8269
​🌐 __Website__ : http://www.quebec.ai
​📝 __LinkedIn__ : https://www.linkedin.com/in/quebecai
​🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Administrative Head Office*
​
#__AIFirst__ #__QuebecAI__ #__QuebecArtificialIntelligence__
