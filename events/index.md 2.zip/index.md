---
title: QUÉBEC.AI | Québec Artificial Intelligence
---
## **QUÉBEC.AI EVENTS**

### **Salon | Press Dinner | Concert | Art Auction | Charity Gala**

![Québec.AI Events](../images/QuebecAIv6WhatIsAI1440x1440.jpg "Québec.AI Events")

## **❖ MONTREAL.AI AI Debates Series**

### **AI DEBATE 2: December 23, 2020, 4:00 PM – 7:00 PM EST | "Moving AI Forward: An Interdisciplinary Approach"**

[![MONTREAL.AI AI Debates Series | AI DEBATE 2 : MARK YOUR CALENDAR — December 23, 2020, 4:00 PM – 7:00 PM EST](../images/aidebate2mosaic1440x720v8.jpg "MONTREAL.AI AI Debates Series | AI DEBATE 2 : MARK YOUR CALENDAR — December 23, 2020, 4:00 PM – 7:00 PM EST")](https://aidebate.eventbrite.ca)

#### **Schedule**

**Panel 1**: _Architecture and Challenges_

**Panel 2**: _Insights from Neuroscience and Psychology_

**Panel 3**: _Towards AI we Can Trust_

#### **Confirmed Speakers**

- _**Ryan Calo**_;
- _**Yejin Choi**_;
- _**Daniel Kahneman**_;
- _**Celeste Kidd**_;
- _**Christof Koch**_;
- _**Luis Lamb**_;
- _**Fei-Fei Li**_;
- _**Adam Marblestone**_;
- _**Margaret Mitchell**_;
- _**Robert Osazuwa Ness**_;
- _**Judea Pearl**_;
- _**Francesca Rossi**_;
- _**Ken Stanley**_;
- _**Rich Sutton**_;
- _**Doris Tsao**_; and
- _**Barbara Tversky**_.

Moderator and co-organizer (with _Vincent Boucher_): _**Gary Marcus**_

To be part of the conversation on social media: #**AIDebate2**

**AI Debate 2 Website:** https://montrealartificialintelligence.com/aidebate2/

### **Tickets and Group Reservation**

**RSVP:** https://aidebate.eventbrite.ca

__Date and Time:__ Wednesday, December 23, 2020 | 5:00 PM to 8:00 PM EST

<div id="eventbrite-widget-container-89401898485"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '89401898485',
        iframeContainerId: 'eventbrite-widget-container-89401898485',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

### **AI DEBATE 1 : Yoshua Bengio | Gary Marcus**

[![MONTREAL.AI World-Class Events — AI DEBATE 1 : Yoshua Bengio | Gary Marcus](../images/bengio-marcus.jpg "MONTREAL.AI World-Class Events — AI DEBATE 1 : Yoshua Bengio | Gary Marcus")](https://montrealartificialintelligence.com/aidebate/)

At Mila in Montreal, on Monday, December 23, 2019, from 6:30 PM to 8:30 PM (EST), Gary Marcus and Yoshua Bengio debated on the best way forward for AI. ZDNet described the event organized by MONTREAL.AI as a [“Historic Event”](https://www.zdnet.com/article/devils-in-the-details-in-bengio-marcus-ai-debate/). 5,225 tickets were RSVP’d for the live event. [Report on the AI Debate](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/).

**Slides, video, readings** and more can be found on the **MONTREAL.AI** debate [webpage](https://montrealartificialintelligence.com/aidebate/).

**MONTREAL.AI** is grateful to [Gary Marcus](http://garymarcus.com), [Yoshua Bengio](https://mila.quebec/en/yoshua-bengio/), [Mila - Institut Québécois d'Intelligence Artificielle](https://mila.quebec/) and to the collaborative [Montreal AI ecosystem](https://www.facebook.com/groups/MontrealAI/). A special thanks to [Sasha Lu](https://sashaluccioni.com).

[![100 countries and 1,000 cities](../images/attendeescity.jpeg "100 countries and 1,000 cities")](https://www.linkedin.com/pulse/report-ai-debate-vincent-boucher/)

***

### __Deep Reinforcement Learning with OpenAI Gym 101__

On **Sat, February 13, 2021 | 10:00 AM – 11:30 AM EST**, the __General Secretariat of MONTREAL.AI__ will present: "__*Deep Reinforcement Learning with OpenAI Gym 101*__".

<a href="https://reinforcementlearning101.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Deep Reinforcement Learning with OpenAI Gym 101 : Buy Tickets on Eventbrite</a>

[![Online Event: Deep Reinforcement Learning with OpenAI Gym 101](../images/RL101Webinarv19.jpg "Online Event: Deep Reinforcement Learning with OpenAI Gym 101")](https://reinforcementlearning101.eventbrite.ca)

<div id="eventbrite-widget-container-117727240345"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117727240345',
        iframeContainerId: 'eventbrite-widget-container-117727240345',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Language:__ Tutorial (webinar) given in __English__.

> "**_Intelligence is the computational part of the ability to predict and control a stream of experience._**" — Rich Sutton

__Location: This is an online event.__ This is a live streamed webinar with interaction with and among students. *Attendees will receive instructions on how to access the live stream at __9:45 AM (EST) on Sat, Feb. 13, 2021__.*

***

## **❖ QUEBEC AI SYMPOSIUM**

### _Stimulating the Economic Activity, Research and Innovation in AI in Quebec_

[![QUEBEC AI SYMPOSIUM — Stimulating the Economic Activity, Research and Innovation in AI in Quebec](../images/quebecaisymposium.png "QUEBEC AI SYMPOSIUM — Stimulating the Economic Activity, Research and Innovation in AI in Quebec")](https://quebecaisymposium.eventbrite.ca)

The **QUEBEC AI SYMPOSIUM**, administered by [MONTREAL.AI](http://www.montreal.ai) and [QUEBEC.AI](http://www.quebec.ai), is an event to stimulate the economic activity, research and innovation in artificial intelligence in Quebec and thus contribute to the competitiveness and influence of Quebec nationally and internationally.

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Tickets:__ https://quebecaisymposium.eventbrite.ca

__Date And Time:__ __Thu, 10 June 2021 | 9:30 AM – 8:30 PM EDT__.
__Location: Details To Be Announced__.

__Website:__ http://quebecaisymposium.com.

***

## **❖ Chief AI Officers : C-level AI**

### _Executive Education‎_

__*Chief AI Officers : C-level AI*__ harnesses the fundamentals of artificial intelligence on a truly global scale and put them to strategically leverage enterprises, governments and institutions with precision engineering.

[![Chief AI Officers : C-level AI | Executive Education‎](../images/ExecutiveEducation‎.jpg "Chief AI Officers : C-level AI | Executive Education‎")](https://chiefaiofficers.eventbrite.ca)
<a href="https://chiefaiofficers.eventbrite.ca/?ref=elink" target="_blank" style="color:#45494E">Chief AI Officers : C-level AI | Ticket</a>
> "**_In a moment of technological disruption, leadership matters._**" — Andrew Ng

__Success is about actively shaping the game that matters to you.__ This well-crafted C-level professional keynote pioneers a highly impactful understanding of [_transformative artificial intelligence_](https://www.openphilanthropy.org/blog/some-background-our-views-regarding-advanced-artificial-intelligence#Sec1) strategies, at boardroom level, bringing to life new perspectives for state, national, and international organizations.

### Participant Profile
{% pullquote [CSS class] %}
"**_We want to see more life-long learning opportunities, across the board matrix interoperability and the development of Chief AI Officers who possess the knowledges, the skills and the competencies to orchestrate impactful breakthroughs and tangible economic growth for Fortune 500, governments and interagency partners in full compliance with our masterplan : The Montréal AI-First Conglomerate Overarching Program._**" — Vincent Boucher, B. Sc. Physics, M. A. Policy Analysis and M. Sc. Aerospace Engineering (Space Technology), Founding Chairman at Montréal.AI
{% endpullquote %}
__*Chief AI Officers : C-level AI*__  is designed for the : 

- Board Members;
- Captains of Industry;
- Chancellors;
- Chief Executive Officers;
- Commanders;
- Excellences;
- Global Chairs
- High-Potential Executives;
- Iconic Tech Entrepreneurs;
- Luminaries;
- Managing Directors;
- Moguls;
- Philanthropists;
- Presidents;
- Scholars;
- Successful Entrepreneurs and Financiers; and
- Visionary Founders

... who wish to strategically unleash the power of artificial intelligence on a truly global scale.

> "**_Breakthrough in machine learning would be worth 10 Microsofts._**" — Bill Gates

<div id="eventbrite-widget-container-106581813072"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '106581813072',
        iframeContainerId: 'eventbrite-widget-container-106581813072',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

__Location: This is an online event.__

***

## **❖ QUÉBEC.AI Captains of AI Industries Celebration**

### _Honoring Award-Winning Captains of AI Industries & Luminaries_

***

## **❖ Artificial Intelligence 101 | International Webinar**

### _Pioneering an Impactful Understanding of AI_

For the newcomers to artificial intelligence, the __General Secretariat of MONTREAL.AI__ introduces, with authority: "__*Artificial Intelligence 101*__: *The First World-Class Overview of AI for the General Public*".

__Location: This is an online event.__

[![ONLINE EVENT : ARTIFICIAL INTELLIGENCE 101](../images/academy1920cover_v0.jpg "ARTIFICIAL INTELLIGENCE 101")](https://artificialintelligence101.eventbrite.ca)

__AI opens up a world of new possibilities.__ This __Artificial Intelligence 101__ harnesses the fundamentals of AI for the purpose of providing participants with powerful AI tools to *__learn__*, *__deploy__* and *__scale AI__*.

> "**_(AI) will rank among our greatest technological achievements, and everyone deserves to play a role in shaping it._**" — Fei-Fei Li

__Program overview and tickets:__ https://artificialintelligence101.eventbrite.ca

<div id="eventbrite-widget-container-117895790483"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '117895790483',
        iframeContainerId: 'eventbrite-widget-container-117895790483',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Language:__ Tutorial (webinar) given in __English__.
__Date And Time:__ Sat, March 13, 2021 | 10:00 AM – 11:30 AM EST
__Location: This is an online event.__ This is a live streamed webinar with interaction with and among students. *Attendees will receive instructions on how to access at 9:45 AM (EST) on Sat, Mar 13, 2021*.

** The content of the webinar is for your personal use and should not be shared or/and distributed. __In case of force majeure, the event will be postponed to a later date.__

***

## **❖ QUÉBEC.AI Press Dinner**

### _Honoring Award-Winning AI Journalism_

***

## **❖ QUÉBEC.AI's Fine Arts Auction**

### _Unveilling a World of Hidden Secrets..._

![QUÉBEC.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...](../images/AITrillion1440.jpg "QUÉBEC.AI's Fine Arts Auction : Unveilling a World of Hidden Secrets...")

On October 25, 2018, [the first artificial intelligence artwork ever sold at Christie’s auction house shattered expectations, fetching $432,500](https://www.christies.com/Lotfinder/lot_details.aspx?hdnSaleID=27814&LN=363&intsaleid=27814&sid=41bfe836-b0c1-4afa-9298-09cc909345ee). Today, the _House of Québec.AI Fine Arts_ introduces : _Québec.AI's Fine Arts Auction_, the **first international auction dedicated to quintessential fine AI arts**.

> "**_The Artists Creating with AI Won't Follow Trends; THEY WILL SET THEM._**" — Québec.AI Fine Arts

We are getting ready for the first auction. Top art collectors will be able to place bids internationally.

***

## **❖ QUÉBEC.AI Salon**

### _Gathering of People Under the Roof of an Inspiring Host_

***

## **❖ QUÉBEC.AI's Fireside Chat**

***

## **❖ MONTREAL.AI MIXER**

### _Orchestrating synergies amongst AI players, enterprises, governments, institutions and the academia to marshal the Montréal’s AI ecosystem_

[![MONTREAL.AI MIXER — Orchestrating synergies amongst AI players, enterprises, governments, institutions and the academia to marshal the Montréal’s AI ecosystem.](../images/MontrealAIMixerv2.jpg "MONTREAL.AI MIXER — Orchestrating synergies amongst AI players, enterprises, governments, institutions and the academia to marshal the Montréal’s AI ecosystem.")](https://aimixer.eventbrite.ca)

### Tickets and Group Reservation

__Group Reservation:__ : secretariat@montreal.ai

__Tickets:__ https://aimixer.eventbrite.ca

__Date And Time:__ __Thu, 10 June 2021 | 5:30 PM – 7:30 PM EDT__.
__Location: Details To Be Announced__.

***

## **❖ QUÉBEC.AI's Ambassadors Dinner**

***

## **❖ QUÉBEC.AI Orchestra**

### _Pioneering Superhuman Symphonies_

[![QUÉBEC.AI Orchestra: Pioneering Superhuman Symphonies](../images/AIConcert1440x2880v2.jpg "QUÉBEC.AI Orchestra: Pioneering Superhuman Symphonies")](https://aiconcert.eventbrite.ca)

<div id="eventbrite-widget-container-59763841258"></div>

<script src="https://www.eventbrite.ca/static/widgets/eb_widgets.js"></script>

<script type="text/javascript">
    var exampleCallback = function() {
        console.log('Order complete!');
    };

    window.EBWidgets.createWidget({
        // Required
        widgetType: 'checkout',
        eventId: '59763841258',
        iframeContainerId: 'eventbrite-widget-container-59763841258',

        // Optional
        iframeContainerHeight: 425,  // Widget height in pixels. Defaults to a minimum of 425px if not provided
        onOrderComplete: exampleCallback  // Method called when an order has successfully completed
    });
</script>

***

## **❖ QUÉBEC.AI Philanthropic Award Gala**

> "**_It's springtime for AI, and we're anticipating a long summer._**" — Bill Braun, CIO of Chevron

​​✉️ __Email Us__ : info@quebec.ai
​📞 __Phone__ : +1.514.829.8269
​🌐 __Website__ : http://www.quebec.ai
​📝 __LinkedIn__ : https://www.linkedin.com/in/quebecai
​🏛 __Headquarters__ : 350, PRINCE-ARTHUR STREET W., SUITE #2105, MONTREAL [QC], CANADA, H2X 3R4 **Administrative Head Office*
​
#__AIFirst__ #__QuebecAI__ #__QuebecArtificialIntelligence__
